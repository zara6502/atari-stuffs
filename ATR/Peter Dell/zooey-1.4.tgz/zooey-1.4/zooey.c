/* ZooEY 1.0
 * by Rafal BOBER Ciepiela
 * contact: bob_er@interia.pl
 * 2000, 2004
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifdef GETTEXT
#include <libintl.h>
#endif

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mnemonics.h"
#include "zooey.h"

int load_src(char *fname, unsigned char **src, unsigned char **orig)
{
	FILE *input;
	unsigned int a;
	unsigned char *src_buffer, *orig_src;

	input=fopen(fname, "r");
	if (input==NULL)
	{
		return 1;
	}
	fseek(input, 0, SEEK_END);
	src_len=ftell(input);
	fseek(input, 0, SEEK_SET);
	orig_src=malloc((src_len+256)*sizeof(unsigned char));
	if (orig_src==NULL) return 2;
	fread(orig_src, sizeof(unsigned char), src_len, input);
	fclose(input);
	src_buffer=malloc((src_len+256)*sizeof(unsigned char));
	if (src_buffer==NULL) return 3;
	for (a=0;a<src_len;a++)
	{
		if ((*(orig_src+a)>='a') && (*(orig_src+a)<='z'))
			*(src_buffer+a)=*(orig_src+a)-32;
		else
		{
			if (*(orig_src+a)==0x09) *(src_buffer+a)=0x20;
			else *(src_buffer+a)=*(orig_src+a);
		}
	}
	*src=src_buffer;
	*orig=orig_src;
	return 0;
}

int save_obj(char *fname, unsigned char *buffer, unsigned int size)
{
	FILE *output;
	unsigned int a;

	output=fopen(fname, "w");
	if(output==NULL) return 1;
	a=fwrite(buffer, sizeof(unsigned char), size, output);
	if(a!=size) return 2;
	fclose(output);
	return 0;
}

unsigned char check_eol(unsigned char *src, unsigned int len)
{
	unsigned int a;

	for (a=0;a<len;a++)
	{
		switch(*(src+a))
		{
			case 0x0a:
				return 0x0a;
				break;
			case 0x9b:
				return 0x9b;
				break;
			case '.':
				if(strncmp((const char *)(src+a), dot_symbols[0][id_dos], 4)==0)
					return 0x0d;
				if(strncmp((const char *)(src+a), dot_symbols[0][id_unix],5)==0)
					return 0x0a;
				if(strncmp((const char *)(src+a), dot_symbols[0][id_atari],6)==0)
					return 0x9b;
				break;
			default:
				break;
		}
	}
	return 0xff;
}

unsigned int get_number(unsigned char *src, unsigned int *param)
{
	unsigned int a;
	unsigned int c=0, d=0;

	a=*param;
	if (*(src+a)=='$')
	{
		a++;
		while(((*(src+a)>='0') && (*(src+a)<='9')) || ((*(src+a)>='A') && (*(src+a)<='F')))
		{
			if (*(src+a)<='9') c=(*(src+a)-'0')+c*0x10;
			else c=(*(src+a)-'A'+10)+c*0x10;
			a++;
			d++;
		}
		if (d==0) { err_msg=2; *param=a; return 0; }
	}
	else
	{
		if (*(src+a)=='%')
		{
			a++;
			while((*(src+a)=='0') || (*(src+a)=='1'))
			{
				c=(*(src+a)-'0')+c*2;
				a++;
				d++;
			}
			if (d==0) { err_msg=2; *param=a; return 0; }
		}
		else
		{
			while((*(src+a)>='0') && (*(src+a)<='9'))
			{
				c=(*(src+a)-'0')+c*10;
				a++;
				d++;
			}
			if (d==0) { err_msg=2; *param=a; return 0; }
		}
	}
	*param=a;
	return c;
}

unsigned int get_label_value(unsigned char *src, unsigned int *par)
{
	unsigned int a, b;
	unsigned int value=0, index;
	char buffer[line_buffer];

	a=*par;
	b=0;
	while(((*(src+a)>='A') && (*(src+a)<='Z')) || ((*(src+a)>='0') && (*(src+a)<='9')) || (*(src+a)=='_') || (*(src+a)=='.') || (*(src+a)==':'))
	{
		buffer[b]=*(src+a);
		b++;
		a++;
	}
	strcpy(buffer+b, "");
	for (index=0;index<labels;index++)
	{
		if (strcmp(buffer, label_tab[index].Name)==0)
		{
			value=label_tab[index].Value;
			label_tab[index].Need++;
			cur_label=index;
			*par=a;
			return value;
		}
	}
	err_msg=7;
	cur_label=-1;
  *par=a;
	return value;
}

unsigned int get_file_name(unsigned char *src, unsigned int *par, unsigned char *fname)
{
	unsigned int a, add_ext=1;
	unsigned int c;
	char *b;

	a=*par;
	if(*(src+a)!=shift7) return 3;
	a++;
	if(sparta)
	{
		b=strrchr(src+a, '>');
		if(b==NULL)
		{
			if(*(src+a+1)==':') a+=2;
		}
		else a=(unsigned int)b-(unsigned int)src+1;
	}
	else
	{
		if(*(src+a)=='D')
		{
			if(*(src+a+1)==':') a+=2;
			else if(*(src+a+2)==':') a+=3;
		}
	}
	c=0;
	while(*(src+a)!=shift7)
	{
		if(*(src+a)==EOL) return 9;
		if(*(src+a)=='.') add_ext=0;
		a++;
		c++;
	}
	memccpy(fname, src+a-c, shift7, c);
	if(add_ext) memcpy(fname+c, ".asm", 5);
	else *(fname+c)='\0';
	*par=++a;
	check_paths(fname);
	return 0;
}

int check_paths(char *fname)
{
	FILE *file;
	int a;
	char tmp_path[line_buffer];

	a=0;
	file=fopen(fname, "r");
	if(file==NULL)
	{
		a=0;
		while(include_dirs[a]!=NULL)
		{
			if(file!=NULL) fclose(file);
			strcpy(tmp_path, include_dirs[a]);
			strcat(tmp_path, fname);
			file=fopen(tmp_path, "r");
			if(file!=NULL)
			{
				strcpy(fname, tmp_path);
				break;
			}
			++a;
		}
	}
	if(file!=NULL) fclose(file);
	return 0;
}

unsigned int get_label_name(unsigned char *src, unsigned int *addr, unsigned char *buf)
{
	unsigned int a, b, c;
	unsigned char *buffer;

	a=*addr;
	b=0;
	buffer=malloc(line_buffer*sizeof(unsigned char));
	if(!buffer)
	{
		printf(_("%s: Malloc crash! (buffer)\n"), zooey_name);
		exit(3);
	}
	if((*(src+a)>='0') && (*(src+a)<='9')) { return 3; }
	else
	{
		while(((*(src+a)>='A') && (*(src+a)<='Z')) || ((*(src+a)>='0') && (*(src+a)<='9')) || (*(src+a)=='_') || (*(src+a)=='@') || (*(src+a)=='.') || (*(src+a)==':'))
		{
			buffer[b]=*(src+a);
			if(((b+1)%line_buffer)==0)
			{
				tmp_pnt=realloc(buffer, ((b+1)+line_buffer)*sizeof(unsigned char));
				if(!tmp_pnt) { printf(_("%s: Malloc crash! (buffer(2))\n"), zooey_name); exit(3); }
				buffer=tmp_pnt;
			}
			a++;
			b++;
		}
		strcpy(buffer+b, "");
		c=0;
		for(b=0;b<labels;b++) { if (strcmp(label_tab[b].Name, buffer)==0) c=6; }
		if((smbls>0) && (c==0))
		{
			for(b=0;b<smbls;b++) { if(strcmp(symb_tab[b].Name, buffer)==0) c=6; }
		}
		strcpy(buf, buffer);
	}
	*addr=a;
	free(buffer);
	if(strlen(buf)>line_buffer-1) return 9;
	else return c;
}

void next_line(unsigned char *src, unsigned int *par)
{
  while((*(src+*(par))!=EOL) && (*(par)<src_len)) { *par+=1; }
  *par+=1;
}

void print_error(unsigned char *src, unsigned int par, unsigned char id, unsigned int line, unsigned char rep)
{
	unsigned int c;
	unsigned char tmp_text[line_buffer];

	printf("%d%s\n", line, _(errmsg[0][id]));
	if(rep)
	{
		memccpy(tmp_text, src+par, EOL, line_buffer-1);
		for(c=0;c<line_buffer-1;c++)
		{
			if(*(tmp_text+c)==EOL) { *(tmp_text+c)='\0'; break; }
		}
		printf("\t%s\n", tmp_text);
	}
}

void print_wrnmsg(unsigned char *src, unsigned int par, unsigned char id, unsigned int line, unsigned char rep)
{
	unsigned int c;
	unsigned char tmp_text[line_buffer];

	printf("%d%s\n", line, _(wrnmsg[0][id]));
	u_warnings=1;
	if(rep)
	{
		memccpy(tmp_text, src+par, EOL, line_buffer-1);
		for(c=0;c<line_buffer-1;c++)
		{
			if(*(tmp_text+c)==EOL) { *(tmp_text+c)='\0'; break; }
		}
		printf("\t%s\n", tmp_text);
	}
}

int save_lab(char *fname)
{
	FILE *output;
	int a, b, max_len=0, tmp_len;

	output=fopen(fname, "w");
	if(output==NULL)
	{
		printf(_("Cannot create label's report.\n"));
		return 1;
	}
	for(a=0;a<labels;a++) { if(strlen(label_tab[a].Name)>max_len) max_len=strlen(label_tab[a].Name); }
	if(max_len<6) max_len=6;
	fprintf(output, "Generated by %s.\nName", zooey_name);
	for(b=0;b<max_len-2;b++) fprintf(output, " ");
	fprintf(output, "  Dec   Hex  Line     Info\n");
	for(a=0;a<labels;a++)
	{
		tmp_len=strlen(label_tab[a].Name);
		fprintf(output, "%s", label_tab[a].Name);
		for(b=0;b<(max_len+1)-tmp_len;b++) fprintf(output, " ");
		if(label_tab[a].Reloc) label_tab[a].Value-=0x1000;
		if(label_tab[a].Value>9999) fprintf(output, " %d", label_tab[a].Value);
		else
		{
			if(label_tab[a].Value>999) fprintf(output, "  %d", label_tab[a].Value);
			else
			{
				if(label_tab[a].Value>99) fprintf(output, "   %d", label_tab[a].Value);
				else
				{
					if(label_tab[a].Value>9) fprintf(output, "    %d", label_tab[a].Value);
					else fprintf(output, "     %d", label_tab[a].Value);
				}
			}
		}
		if(label_tab[a].Value>0x0fff) fprintf(output, " $%x", label_tab[a].Value);
		else
		{
			if(label_tab[a].Value>0xff) fprintf(output, " $0%x", label_tab[a].Value);
			else
			{
				if(label_tab[a].Value>0x0f) fprintf(output, " $00%x", label_tab[a].Value);
				else fprintf(output, " $000%x", label_tab[a].Value);
			}
		}
		fprintf(output, "  %d", label_tab[a].Line);
		if((label_tab[a].Reloc) || (label_tab[a].Need==0))
		{
			if(label_tab[a].Line>9999) fprintf(output, "    ");
			else
			{
				if(label_tab[a].Line>999) fprintf(output, "     ");
				else
				{
					if(label_tab[a].Line>99) fprintf(output, "      ");
					else
					{
						if(label_tab[a].Line>9) fprintf(output, "       ");
						else fprintf(output, "        ");
					}
				}
			}
			b=0;
			if(label_tab[a].Reloc>0) { fprintf(output, "Reloc"); b=1; }
			if(label_tab[a].Need==0)
			{
				if(b) fprintf(output, ",");
				fprintf(output, "Unused");
			}
		}
		fprintf(output, "\n");
	}
	fprintf(output, "Total: %d label(s).\n", labels);
	fclose(output);
	return 0;
}

unsigned int get_value(unsigned char *src, unsigned char *orig, unsigned int *as_pnt, unsigned short int reg_pc, unsigned int line, unsigned int *symbol, unsigned int fin_mask)
{
	unsigned int a, outop[line_buffer], tmp_a, c;
	unsigned int bufop_idx, outop_idx, mask, val, id, end_mask;
	unsigned char unbals, mode, bufop[line_buffer], outop2[line_buffer], out, done, reloc;

	a=*as_pnt;
	reloc=done=out=mode=unbals=0;
	bufop_idx=outop_idx=val=id=end_mask=0;
	mask=0xffffffff;
	cur_label=-1;
	while(*(src+a)==' ') a++;
	while((*(src+a)!=EOL) && (!out))
	{
		done=1;
		switch (*(src+a))
		{
			case '(':
				if(!mode)
				{
					a++;
					unbals++;
					bufop[bufop_idx]=0xf1;
					bufop_idx++;
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			case ')':
				if(mode)
				{
					if(!unbals) { out=1; break; }
					a++;
					unbals--;
					while((bufop[bufop_idx-1]!=0xf1) && (bufop_idx))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop_idx--;
					if(bufop[bufop_idx]!=0xf1) { *as_pnt=a; err_msg=8; return 0; }
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			case '^':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x10) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x11;
					bufop_idx++;
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			case '*':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x20) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x21;
					bufop_idx++;
				}
				else goto value;
				break;
			case '/':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x20) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x22;
					bufop_idx++;
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			case '%':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x20) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x23;
					bufop_idx++;
				}
				else goto value;
				break;
			case '+':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x30) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x31;
					bufop_idx++;
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			case '-':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x30) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x32;
					bufop_idx++;
				}
				else
					goto value;
				break;
			case '>':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x40) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x41;
					bufop_idx++;
				}
				else
				{
					if(!id) { end_mask=0xff00; a++; }
					goto value;
				}
				break;
			case '<':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x40) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x42;
					bufop_idx++;
				}
				else
				{
					if(!id) { end_mask=0xff; a++; }
					goto value;
				}
				break;
			case '=':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x50) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x51;
					bufop_idx++;
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			case '!':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x60) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x61;
					bufop_idx++;
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			case '&':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x70) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x71;
					bufop_idx++;
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			case '|':
				if(mode)
				{
					a++;
					mode=0;
					while(((bufop[bufop_idx-1]&0xf0)<=0x80) && (bufop_idx>0))
					{
						bufop_idx--;
						if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
						{
							outop[outop_idx-2]=calculate(bufop[bufop_idx], outop[outop_idx-2], outop[outop_idx-1]);
							outop2[outop_idx-2]=0;
							outop_idx--;
						}
						else { outop[outop_idx]=bufop[bufop_idx]; outop2[outop_idx]=1; outop_idx++; }
					}
					bufop[bufop_idx]=0x81;
					bufop_idx++;
				}
				else { *as_pnt=a; err_msg=3; return 0; }
				break;
			default:
value:
				if(mode) { out=1; break; }
				mode=1;
				id++;
				if(*(src+a)!=EOL)
				{
					char minus;

					if(*(src+a)=='-') { minus=1; a++; }
					else minus=0;
					if(*(src+a)=='<') { mask=0xff; a++; } else if (*(src+a)=='>') { mask=0xff00; a++; }
/* etykiety */
					if(((*(src+a)>='A') && (*(src+a)<='Z')) || (*(src+a)=='_'))
					{
						tmp_a=a;
						val=get_label_value(src, &a);
						if(cur_label>=0) { if(label_tab[cur_label].Reloc>0) reloc=1; }
						if((err_msg==7) && ((*(symbol)>0) && (*(symbol)<10)) && ((header==0xfeff) || (header==0xfaff)))
						{
							for(c=0;c<smbls;c++)
							{
								if(strncmp((const char *)(src+tmp_a), symb_tab[c].Name, strlen(symb_tab[c].Name))==0)
								{
									err_msg=0;
									a=tmp_a+strlen(symb_tab[c].Name);
									symb_tab[c].Need++;
									if(*(symbol)==2) val=0x8000;
									else val=0;
									*(symbol)=10+c;
									break;
								}
							}
						}
					}
				  else
			  	{
/* biezacy pc */
						if (*(src+a)=='*') { val=reg_pc; a++; reloc=1; }
						else
						{
/* stale 'A' */
							if (*(src+a)==shift7)
							{
								a++;
								val=*(orig+a);
								a++;
								if (*(src+a)!=shift7)
									{ *as_pnt=a; err_msg=9; return 0; }
								else
								{
									a++;
									if (*(src+a)=='*') { val=val^0x80; a++; }
								}
							}
/* stale "A" */
							else if(*(src+a)=='"')
							{
								a++;
								val=*(orig+a);
								if(val<128) { if(val<32) val+=64; else if(val<96) val-=32; }
								else { if(val<160) val+=64; else if(val<224) val-=32; }
								a++;
								if (*(src+a)!='"')
									{ *as_pnt=a; err_msg=9; return 0; }
								else
								{
									a++;
									if (*(src+a)=='*') { val=val^0x80; a++; }
								}
							}
/* opcode :lda #$00 */
							else if(*(src+a)==':')
							{
								a++;
								if((*(src+a)==' ') || (*(src+a)==EOL))
									{ *as_pnt=a; err_msg=11; return 0; }
								for(c=0;c<=id_6502_last;c++)
								{
									if(strncmp((const char *)(src+a), mnemonics[0][c], 3)==0)
									{
										int d=0;
										
										a+=3;
										if(mch_code[c][11]) d=11;
										else
										{
											d=get_addr_mode(src, a, reg_pc, line, &d);
											d=d&0x3f;
											a=skip_operand(src, a, d);
										}
										val=mch_code[c][d];
										if((val==0) && (c!=id_brk)) { *as_pnt=a; err_msg=11; return 0; }
										break;
									}
								}
							}
/* parametr makra */
					  	else if(*(src+a)=='\\')
							{
								if(inmacro)
								{
									a++;
									if(obj_buffer==0)
									{
										val=get_number(src, &a);
										param=val;
										if(val>mac_params) mac_params=val;
									}
									else
									{
										val=get_number(src, &a)-1;
										val=mac_args[val];
									}
								}
								else { err_msg=2; *as_pnt=a; return val; }
							}
							else
						  	{
/* wartosc liczbowa */
						  		if (((*(src+a)>='0') && (*(src+a)<='9')) || ((*(src+a)=='$') || (*(src+a)=='%')))
										val=get_number(src, &a);
								  else { out=1; break; }
						  	}
					  }
					}
					if(minus==1)
						val=0-val;
					val=val&mask;
					if(mask==0xff00) val=val>>8;
					mask=0xffffffff;
					outop[outop_idx]=val;
					outop2[outop_idx]=0;
					outop_idx++;
				}
				break;
		}
	}
	for(mask=bufop_idx;mask>0;mask--)
	{
		if((outop_idx>1) && ((!outop2[outop_idx-1]) && (!outop2[outop_idx-2])))
		{
			outop[outop_idx-2]=calculate(bufop[mask-1], outop[outop_idx-2], outop[outop_idx-1]);
			outop2[outop_idx-2]=0;
			outop_idx--;
		}
		else { outop[outop_idx]=bufop[mask-1]; outop2[outop_idx]=1; outop_idx++; }
	}
	*as_pnt=a;
	if (unbals) { err_msg=8; return 0; }
	val=outop[0];
	if(outop_idx>1)
	{
		for(mask=1;mask<outop_idx;mask++)
		{
			val=calculate(outop[mask+1], val, outop[mask]);
			mask++;
		}
	}
//	val=val&0xffff;
	if(!mode) err_msg=2;
	if(end_mask)
	{
		val=val&end_mask;
		if(end_mask==0xff00) val=val>>8;
	}
	if((*symbol<10) && (reloc)) *symbol=5;
	val=val&fin_mask;
	return val;
}

unsigned int calculate(unsigned int op, unsigned int at1, unsigned int at2)
{
	unsigned int val=0;

	switch (op)
	{
		case 0x81:
			val=at1|at2;
			break;
		case 0x71:
			val=at1&at2;
			break;
		case 0x61:
			val=at1^at2;
			break;
		case 0x51:
			if(at1==at2) val=1;
			else val=0;
			break;
		case 0x41:
			if(at1>at2) val=1;
			else val=0;
			break;
		case 0x42:
			if(at1<at2) val=1;
			else val=0;
			break;
		case 0x31:
			val=at1+at2;
			break;
		case 0x32:
			val=at1-at2;
			break;
		case 0x21:
			val=at1*at2;
			break;
		case 0x22:
			val=at1/at2;
			break;
		case 0x23:
			val=at1%at2;
			break;
		case 0x11:
			val=(unsigned int)pow((double)at1, (double)at2);
			break;
		default:
			err_msg=3;
	}
	return val;
}

unsigned char get_addr_mode(unsigned char *src, unsigned int a, unsigned short int cur, unsigned int cur_line, unsigned int *symb)
{
	unsigned int b;
	unsigned int value;

	while(*(src+a)==' ') a++;
	b=a;
	*(symb)=2;
	if(*(src+a)==EOL) return 11;       /* nop */
	if ((*(src+a)=='#') || (*(src+a)=='<') || (*(src+a)=='>')) return 1;     /* lda #$f2 */
	if (*(src+a)=='@') return 12;       /* asl @ */
	if (*(src+a)=='(')
	{
		a++;
		get_value(src, src, &a, cur, cur_line, symb, 0xffffffff);
		if (err_msg==7) { err_msg=0; value=0xf2f2; }
		while (*(src+a)==' ') a++;
		if (*(src+a)==')')
		{
			a++;
			if ((*(src+a)==',') && (*(src+a+1)=='Y')) return 9;   /* lda (10),y */
			if ((*(src+a)==' ') || (*(src+a)==EOL)) return 10;      /* jmp (620) */
		}
		if ((*(src+a)==',') && (*(src+a+1)=='X') && (*(src+a+2)==')')) return 8; /* lda (1,x) */
		err_msg=0;
		if ((!(((*(src+b)>='A') && (*(src+b)<='Z')) || ((*(src+b)>='0') && (*(src+b)<='9'))
			|| (*(src+b)=='_'))) && ((*(src+b)!='(') && (*(src+b)!='$') && (*(src+b)!='%')
			&& (*(src+b)!='*'))) { err_msg=0; return 11; }   /* nop */
		return 0x40+10;
	}
	cur_label=-1;
	param=max_params;
	value=get_value(src, src, &a, cur, cur_line, symb, 0xffffffff);
	if(cur_label>=0) { if (label_tab[cur_label].Total_Line>cur_line) value=0xf2f2; }
	if(err_msg==7) { err_msg=0; value=0xf2f2; }
	if((inmacro) && (param<max_params) && (!obj_buffer)) { value=0xf2; }
	if ((*(src+a)==' ') || (*(src+a)==EOL))
	{
		if (value>0xff) return 2; else return 3;  /* lda 620; lda 20 */
	}
	if ((*(src+a)==',') && (*(src+a+1)=='X'))
	{
		if (value>0xff) return 4; else return 6;  /* adc 620,x; adc 20,x */
	}
	if ((*(src+a)==',') && (*(src+a+1)=='Y'))
	{
		if (value>0xff) return 5; else return 7;  /* ldx 620,y; ldx 20,y */
	}
	if ((!(((*(src+b)>='A') && (*(src+b)<='Z')) || ((*(src+b)>='0') && (*(src+b)<='9'))
		|| (*(src+b)=='_'))) && ((*(src+b)!='(') && (*(src+b)!='$') && (*(src+b)!='%')
		&& (*(src+b)!='*') && (*(src+b)!='\\'))) { err_msg=0; return 11; }  /* nop */
	if (value>0xff) return 0x40+2; else return 0x40+3;  /* lda 620; lda 20 */
	return 0;
}

unsigned int skip_operand(unsigned char *src, unsigned int a, unsigned char addr_mode)
{
	int b=0;

	while(*(src+a)==' ') a++;
	switch(addr_mode)
	{
		case 1:
			a++;
			get_value(src, src, &a, 0, 0, &b, 0xffff);
			break;
		case 2:
		case 3:
			get_value(src, src, &a, 0, 0, &b, 0xffff);
			break;
		case 4:
		case 5:
		case 6:
		case 7:
		case 9:
			while(*(src+a)!=',') a++;
			a+=2;
			break;
		case 8:
		case 10:
			a++;
			while(b>=0)
			{
				if(*(src+a)==')') b--;
				if(*(src+a)=='(') b++;
				a++;
			}
			break;
		case 12:
			a++;
			break;
		case 11:
		default:
			break;
	}
	return a;
}

unsigned int pass1(unsigned char *src, unsigned char *orig, unsigned int rec_level)
{
	unsigned int a=0, old_a=0, symb;
	unsigned int line=0, b, done, c, d, errors=0, addr_mode=0;
	unsigned char dta_ex=0, tmp_text[line_buffer], cpu_mode=1, ass=1;

	if (!rec_level)
	{
		blck_id=1;
		block_tab[blocks].Start=0;
		block_tab[blocks].Need=header;
		block_tab[blocks].Line=0;
		block_tab[blocks].Header=0xffff;
	}
	symb=0;
	while(a<src_len)
	{
		done=0;
		total_line++;
		line++;
		if(err_msg)
		{
			if(rec_level) printf(_("\tIn file '%s':\n"), icl_tab[icls-1].File_Name);
			print_error(orig, old_a, err_msg, line-1, report);
			errors++;
			err_msg=0;
		}
		old_a=a;
		if(print)
		{
			memccpy(tmp_text, orig+a, EOL, line_buffer-1);
			for(c=0;c<line_buffer-1;c++)
			{
				if(*(tmp_text+c)==EOL) { *(tmp_text+c)='\0'; break; }
			}
			if(reg_pc<0x10) printf("$000%x\t%s\n", reg_pc, tmp_text);
			else if(reg_pc<0x100) printf("$00%x\t%s\n", reg_pc, tmp_text);
			  else if(reg_pc<0x1000) printf("$0%x\t%s\n", reg_pc, tmp_text);
			    else printf("$%x\t%s\n", reg_pc, tmp_text);
		}
		if(inmacro==2) inmacro=1;
		switch(*(src+a))
		{
			case '*':
			case '#':
			case ';':
/* komentarz */
				next_line(src, &a);
				break;
			case ' ':
/* rozkazy lub pusty wiersz */
rest_line:
				while((*(src+a)==' ') && (a<src_len)) {a++;}
				if (*(src+a)==EOL) { a++; break; }
				if(a>=src_len) break;
/* .komendy */
				old_pc=reg_pc;
				if((!ifstack[iflevel]) && ((*(src+a+3)==' ') || (*(src+a+3)==EOL)))
				{
					for (b=0;b<=id_6502_last;b++)
					{
						if (strncmp((const char *)(src+a), mnemonics[0][b], 3)==0)
						{
							a+=3;
							done=1;
							d=max_params;
							param=d;
							if(mch_code[b][11]) addr_mode=11;
							else addr_mode=get_addr_mode(src, a, reg_pc, total_line, &symb);
							if(addr_mode>=0x40) addr_mode=0;
							if(symb>=10)
							{
								u_smbls++;
								if((header==0xfeff) || (header==0xfaff)) symb=1;
								else symb=0;
							}
							else if(symb==2) symb=1;
							if((cpu_level[b][addr_mode]&cpu_mode)!=cpu_level[b][addr_mode])
							{
								err_msg=23;
								reg_pc++;
								next_line(src, &a);
							}
							else
							{
								if((inmacro) && (err_msg==0))
								{
									get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
									err_msg=0;
								}
								if((addr_mode==3) && (((mch_code[b][2]&0x1f)==0x10) || (b==id_bra))) addr_mode=2;
								if (mch_code[b][addr_mode])
								{
									if(!ass)
									{
										err_msg=24;
										next_line(src, &a);
										break;
									}
									if(inmacro)
									{
										if(param!=d)
										{
											c=addr_modes[addr_mode];
											if(mch_code[b][addr_mode]!=mch_code[b][c])
												{ macro_tab[macros].Diffs[param-1]++; }
											addr_mode=c;
											param=0;
										}
									}
									switch (addr_mode)
									{
										case 1:
										case 3:
										case 6:
										case 7:
										case 8:
										case 9:
											if(header==0xfeff) jumps++;
											if (mch_code[b][addr_mode]==mch_code[b][2]) reg_pc++;
											if (mch_code[b][addr_mode]==mch_code[b][5]) reg_pc++;
											if (mch_code[b][addr_mode]==mch_code[b][4]) reg_pc++;
											reg_pc+=2;
											next_line(src, &a);
											break;
										case 2:
										case 4:
										case 5:
										case 10:
											if((header==0xfeff) || (header==0xfaff)) jumps++;
											if ((b==id_jmp) && (addr_mode==10) && ((reg_pc&0xff)==0xfe) && (report))
												{ print_wrnmsg(orig, old_a, 5, line, report); }
											if((addr_mode==2) && (((mch_code[b][addr_mode]&0x1f)==0x10) || (b==id_bra))) reg_pc+=2;
											else reg_pc+=3;
											next_line(src, &a);
											break;
										case 11:
										case 12:
											reg_pc++;
											next_line(src, &a);
											break;
									}
								}
								else
								{
									err_line=line;
									if(!addr_mode) err_msg=15;
									else err_msg=11;
									reg_pc++;
									next_line(src, &a);
								}
								break;
							}
						}
					}
					if (old_pc!=reg_pc) continue;
				}
				if (done) break;
				if(*(src+a)=='.')
				{
					for(b=0;b<id_dot_cnst_last;b++)
					{
						if((strncmp((const char *)(src+a), dot_symbols[0][b], dot_symbol_len[b])==0) && ((*(src+a+dot_symbol_len[b])==EOL) || (*(src+a+dot_symbol_len[b])==' ')))
						{
							done=1;
							switch(b)
							{
/* ------------------------------ .65c02 ------------------------- */
								case id_65c02:
									if(!ifstack[iflevel])
									{
										cpu_mode=cpu_mode|0x02;
										if(inmacro) err_msg=3; 
										next_line(src, &a);
									}
									else done=0;
									break;
/* ------------------------------ .unpbl ------------------------- */
								case id_unpbl:
									if(!ifstack[iflevel])
									{
										cpu_mode=cpu_mode|0x04;
										if(inmacro) err_msg=3; 
										next_line(src, &a);
									}
									else done=0;
									break;
/* ------------------------------ .atari ------------------------- */
/* ------------------------------ .unix -------------------------- */
								case id_atari:
								case id_unix:
									if(!ifstack[iflevel])
									{
										if(inmacro) err_msg=3;
										else if(line>1) err_msg=21;
										next_line(src, &a);
									}
									else done=0;
									break;
/* ------------------------------ .dos ------------------------- */
								case id_dos:
									if(!ifstack[iflevel])
									{
										if(inmacro) err_msg=3;
										else if(line>1) err_msg=21;
										if(report) print_wrnmsg(orig, old_a, 1, line, report);
										next_line(src, &a);
									}
									else done=0;
									break;
/* ------------------------------ .ifdef ----------------------- */
								case id_ifdef:
									if(*(src+a+6)==' ')
									{
										if(iflevel==(max_depth-1)) err_msg=25;
										if((!err_msg) && (!ifstack[iflevel]) && (!ifignore))
										{
											a+=6;
											while(*(src+a)==' ') a++;
											b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											iflevel++;
											if(err_msg!=7) ifstack[iflevel]=0;
											else ifstack[iflevel]=1;
											err_msg=0;
										}
										else ifignore++;
									}
									else
									{
										if(*(src+a+6)==EOL) err_msg=4;
										else done=0;
									}
									next_line(src, &a);
									break;
/* ------------------------------ .if -------------------------- */
								case id_if:
									if(*(src+a+3)==' ')
									{
										if(iflevel==(max_depth-1)) err_msg=25;
										if((!err_msg) && (!ifstack[iflevel]) && (!ifignore))
										{
											a+=3;
											while(*(src+a)==' ') a++;
											b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											iflevel++;
											if(b) ifstack[iflevel]=0;
											else ifstack[iflevel]=1;
										}
										else ifignore++;
									}
									else
									{
										if(*(src+a+3)==EOL) err_msg=4;
										else done=0;
									}
									next_line(src, &a);
									break;
/* ------------------------------ .else ------------------------ */
								case id_else:
									if(iflevel>0)
									{
										if(!ifignore)
										{
											if(ifstack[iflevel]==0) ifstack[iflevel]=13;
											else
											{
												if(ifstack[iflevel]==1) ifstack[iflevel]=0;
												else ifstack[iflevel]=3;
											}
										}
										next_line(src, &a);
									}
									else
									{
										if(!iflevel) err_msg=26;
										else err_msg=12;
										next_line(src, &a);
									}
									break;
/* ----------------------------- .elif ------------------------- */
								case id_elif:
									if(*(src+a+5)==' ')
									{
										if(!iflevel) err_msg=26;
										if((!err_msg) && (!ifignore))
										{
											a+=5;
											while(*(src+a)==' ') a++;
											b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											if((b) && (ifstack[iflevel]<10) && (ifstack[iflevel]>0)) { ifstack[iflevel]=0; }
											else
												{ if(ifstack[iflevel]==0) ifstack[iflevel]=12; }
										}
									}
									else
									{
										if(*(src+a+5)==EOL) err_msg=4;
										else done=0;
									}
									next_line(src, &a);
									break;
/* ----------------------------- .fi --------------------------- */
								case id_fi:
									if(!iflevel) err_msg=26;
									if(ifignore) ifignore--;
									else iflevel--;
									next_line(src, &a);
									break;
								default:
									err_msg=12;
									next_line(src, &a);
									break;
							}
						}
					}
					if(!done)
					{
						err_msg=12;
						next_line(src, &a);
					}
					break;
				}
				if(done) { break; }
				if(ifstack[iflevel]) { next_line(src, &a); break; }
/* komendy QA */
				for(b=0;b<id_cnst_last;b++)
				{
					if(((strncmp((const char *)(src+a), symbols[0][b], 3)==0) && (ifstack[iflevel]==0)) && ((*(src+a+3)==EOL) || (*(src+a+3)==' ')))
					{
						done=1;
						switch(b)
						{
/* ------------------------------ bin ------------------------- */
							case id_bin:
								a+=3;
								if(*(src+a)==EOL)
								{
									err_msg=4;
									next_line(src, &a);
									break;
								}
								if(!ass)
								{
									err_msg=24;
									next_line(src, &a);
									break;
								}
								while(*(src+a)==' ') a++;
								if(*(src+a)!=shift7) err_msg=3;
								else
								{
									FILE *tmp_file;
									unsigned int tmp_size=0, minus;

									err_msg=get_file_name(orig, &a, tmp_text);
									tmp_file=fopen(tmp_text, "r");
									if (tmp_file==NULL) { err_msg=18; }
									else
									{
										fseek(tmp_file, 0, SEEK_END);
										tmp_size=ftell(tmp_file);
										fclose(tmp_file);
										b=tmp_size;
									}
									if((*(src+a)==',') && (!err_msg))
									{
										if(*(src+a+1)=='-') { a+=2; minus=1; }
										else { a++; minus=0; }
										c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
										if(minus) b=abs(c); else b=tmp_size-c;
										if(*(src+a)==',')
										{
											a++;
											b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											if(b>tmp_size) { print_wrnmsg(orig, old_a, 4, line, report); }
										}
									}
									reg_pc+=b;
								}
								next_line(src, &a);
								break;
/* ------------------------------ cos ------------------------- */
/* ------------------------------ sin ------------------------- */
							case id_cos:
							case id_sin:
								a+=3;
								if(*(src+a)==EOL)
									{ err_msg=4; next_line(src, &a); break; }
								c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
								if(!ass)
									{ err_msg=24; next_line(src, &a); break; }
								if(!err_msg)
								{
									if(c>0x7f) err_msg=1;
									else
									{
										b=0;
										while(*(src+a)!=EOL)
										{
											if(*(src+a)==',')
											{
												b=1;
												a++;
												reg_pc+=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												break;
											}
											a++;
										}
										if(!b) err_msg=4;
									}
								}
								next_line(src, &a);
								break;
/* ------------------------------ dta ------------------------- */
							case id_dta:
								a+=3;
								if(*(src+a)==EOL)
									{ err_msg=4; next_line(src, &a); break; }
								if(!ass)
									{ err_msg=24; next_line(src, &a); break; }
								dta_ex=0;
								while(*(src+a)==' ') { a++; }
								while(*(src+a)!=EOL)
								{
									switch(*(src+a))
									{
										case 'A':
										case 'V':
											if((*(src+a+1)=='(') && (!dta_ex))
											{
												dta_ex=1;
												a+=2;
												c=1;
												d=0;
												while(c!=0)
												{
													if(*(src+a)=='(') { c++; a++; continue; }
													if(*(src+a)==')') { c--; a++; continue; }
													if(*(src+a)==',')
													{
														if(d>0) err_msg=2;
														a++; d=1; continue;
													}
													d=err_msg;
													get_value(src, orig, &a, reg_pc, line, &symb, 0xffff);
													err_msg=d;
													d=0;
													reg_pc+=2;
													jumps++;
													if(*(src+a)==EOL)
													{
														err_msg=4;
														break;
													}
												}
												if(d!=0) err_msg=2;
											}
											else err_msg=3;
											break;
										case 'B':
										case 'H':
										case 'L':
											if((*(src+a+1)=='(') && (!dta_ex))
											{
												dta_ex=1;
												a+=2;
												c=1;
												d=0;
												while(c!=0)
												{
													if(*(src+a)=='(') { c++; a++; continue; }
													if(*(src+a)==')') { c--; a++; continue; }
													if(*(src+a)==',')
													{
														if(d>0) err_msg=2;
														a++; d=1; continue;
													}
													d=err_msg;
													get_value(src, orig, &a, reg_pc, line, &symb, 0xffff);
													err_msg=d;
													d=0;
													reg_pc++;
													if(*(src+a)==EOL)
													{
														err_msg=4;
														break;
													}
												}
												if(d!=0) err_msg=2;
											}
											else err_msg=3;
											break;
										case 'C':
										case 'D':
											if((*(src+a+1)==shift7) && (!dta_ex))
											{
												dta_ex=1;
												a+=2;
												c=1;
												while(c!=0)
												{
													if(*(src+a)==shift7)
													{
														if(*(src+a+1)==shift7) a++;
														else c=0;
													}
													if(*(src+a)==EOL)
													{
														err_msg=4;
														break;
													}
													reg_pc++;
													a++;
												}
												if(*(src+a)=='*') { a++; }
												reg_pc--;
											}
											else
											{
												err_msg=3;
												next_line(src, &a);
											}
											break;
										case 'T':
										case 'E':
											if((*(src+a+1)=='(') && (!dta_ex))
											{
												dta_ex=1;
												a+=2;
												c=1;
												d=0;
												while(c!=0)
												{
													if(*(src+a)=='(') { c++; a++; continue; }
													if(*(src+a)==')') { c--; a++; continue; }
													if(*(src+a)==',')
													{
														if(d>0) err_msg=2;
														a++; d=1; continue;
													}
													d=err_msg;
													get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
													err_msg=d;
													d=0;
													reg_pc+=3;
													if(*(src+a)==EOL)
													{
														err_msg=4;
														break;
													}
												}
												if(d!=0) err_msg=2;
											}
											else err_msg=3;
											break;
										case 'F':
										case 'G':
											if((*(src+a+1)=='(') && (!dta_ex))
											{
												dta_ex=1;
												a+=2;
												c=1;
												d=0;
												while(c!=0)
												{
													if(*(src+a)=='(') { c++; a++; continue; }
													if(*(src+a)==')') { c--; a++; continue; }
													if(*(src+a)==',')
													{
														if(d>0) err_msg=2;
														a++; d=1; continue;
													}
													d=err_msg;
													get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
													err_msg=d;
													d=0;
													reg_pc+=4;
													if(*(src+a)==EOL)
													{
														err_msg=4;
														break;
													}
												}
												if(d!=0) err_msg=2;
											}
											else err_msg=3;
											break;
										case ',':
											if(dta_ex) { dta_ex=0; a++; }
											else err_msg=3;
											break;
					          case ' ':
											next_line(src, &a);
											a--;
											break;
										default:
											err_msg=3;
											next_line(src, &a);
											a--;
											break;
									}
								}
								if(!dta_ex) err_msg=15;
								next_line(src, &a);
								break;
/* ------------------------------ end ------------------------- */
							case id_end:
								if(inmacro)
								{
									err_msg=26;
									next_line(src, &a);
									break;
								}
								if(!rec_level)
								{
									if((block_tab[blocks].Start!=reg_pc) || ((block_tab[blocks].Header!=0xffff) && (block_tab[blocks].Header!=0xfeff) && (block_tab[blocks].Header!=0xfaff)))
									{
										d=0;
										if((block_tab[blocks].Header==0xfaff) || (block_tab[blocks].Header==0xffff))
											{ block_tab[blocks].End=reg_pc-1; }
										else
										{
											if(block_tab[blocks].Header==0xfeff)
											{
												b=block_tab[blocks].Mode;
												if((b==0x80) || (b==0x82))
												{
													d=0x1000;
													block_tab[blocks].End=reg_pc-0x1000;
													reg_pc+=block_tab[blocks].Start;
												}
												else block_tab[blocks].End=reg_pc-1;
												sparta_mem[blck_id-1]=sparta_mem[blck_id-2]+reg_pc-0x1000;
											}
											else block_tab[blocks].End=reg_pc;
										}
										c=(reg_pc-block_tab[blocks].Start)-d;
										if((block_tab[blocks].Header!=0xffff) && (block_tab[blocks].Header!=0xfaff) && (block_tab[blocks].Header!=0x0000)) delta=reg_pc-0x1000;
										if((cpu_mode&0x08)==0)
										{
											if((((block_tab[blocks].End&0xffff)+1)<(block_tab[blocks].Start&0xffff)) && (warnings) && (block_tab[blocks].Header!=0xfeff))
											{
												print_wrnmsg(orig, old_a, 2, block_tab[blocks].Line, 0);
												c=(0x10000-block_tab[blocks].Start)+block_tab[blocks].End+1;
											}
										}
										obj_len+=c;
									}
									else
									{
										block_tab[blocks].Need=0;
									}
									blocks++;
								}
								ret=1;
								if(iflevel) { printf("%d%s\n", line, _(errmsg[0][26])); }
								return errors;
/* ------------------------------ enm ------------------------- */
							case id_enm:
								if(!inmacro) err_msg=26;
								else
								{
									c=macro_tab[macros].Size;
									macro_tab[macros].Size=reg_pc;
									b=macro_tab[macros].Params;
									macro_tab[macros].Params=mac_params;
									if(b>mac_params) mac_params=b;
									reg_pc=c;
									inmacro--;
									macro_tab[macros].A=a;
									macro_tab[macros].Line=line;
									macros++;
								}
								next_line(src, &a);
								break;
/* ------------------------------ equ ------------------------- */
/* ------------------------------ mac ------------------------- */
/* ------------------------------ smb ------------------------- */
							case id_smb:
							case id_mac:
							case id_equ:
								err_msg=5;
								next_line(src, &a);
								break;
/* ------------------------------ icl ------------------------- */
							case id_icl:
								{
									unsigned int bak_src_len;
									unsigned char *bak_src, *bak_orig, bak_EOL;

									a+=3;
									err_msg=0;
									if(!ass) err_msg=24;
									if(*(src+a)==EOL) err_msg=4;
									while(*(src+a)==' ') a++;
									if(*(src+a)==EOL) err_msg=4;
									c=get_file_name(orig, &a, tmp_text);
									if(c) err_msg=c;
									if((*(src+a)!=EOL) && (*(src+a)!=' ')) err_msg=3;
									if(((icls+1)%max_icls)==0)
									{
										tmp_pnt=realloc(icl_tab, (icls+max_icls)*sizeof(ICL));
										if(!tmp_pnt) { err_msg=22; }
										else { icl_tab=tmp_pnt; }
									}
									if(!err_msg)
									{
										bak_src=src;
										bak_orig=orig;
										bak_src_len=src_len;
										bak_EOL=EOL;
										if(load_src(tmp_text, &src, &orig)) err_msg=18;
										else
										{
											EOL=check_eol(src, src_len);
											if(report)
											{
												switch(EOL)
												{
													case 0x0a:
														printf(_("Setting UNIX($0a) EOL for file '%s'.\n"), tmp_text);
														break;
													case 0x9b:
														printf(_("Setting ATARI($9b) EOL for file '%s'.\n"), tmp_text);
														break;
													case 0xff:
														printf(_("Can't recognize EOL for file '%s'. Setting unix's ($0a) EOL.\n"), tmp_text);
														EOL=0x0a;
														break;
													default:
														printf(_("This EOL ($%x) isn't implemented yet (in file '%s').\n"), EOL, tmp_text);
														return 1;
												}
											}
											ret=0;
											icl_tab[icls].Src_Buffer=src;
											icl_tab[icls].Orig_Src=orig;
											icl_tab[icls].EOL=EOL;
											icl_tab[icls].Length=src_len;
											c=strlen(tmp_text);
											if(c>line_buffer-4) { tmp_text[line_buffer-4]='\0'; c=line_buffer-4; }
											icl_tab[icls].File_Name=malloc((c+4)*sizeof(char));
											strcpy(icl_tab[icls].File_Name, tmp_text);
											icls++;
											errors+=pass1(src, orig, rec_level+1);
										}
										src=bak_src;
										orig=bak_orig;
										src_len=bak_src_len;
										EOL=bak_EOL;
									}
									next_line(src, &a);
									if((rec_level) && (ret) && (qa)) return errors;
									break;
								}
/* ------------------------------ mem ------------------------- */
							case id_mem:
								a+=3;
								if(*(src+a)==EOL)
								{
									err_msg=4;
									next_line(src, &a);
									break;
								}
								if(inmacro)
								{
									err_msg=26;
									next_line(src, &a);
									break;
								}
								while(*(src+a)==' ') { a++; }
								get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
								if(*(src+a)!=',') { err_msg=3; next_line(src, &a); break; }
								else a++;
								get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
								if((*(src+a)==' ') || (*(src+a)==EOL)) err_msg=0;
								else err_msg=3;
								mem_cnt++;
								next_line(src, &a);
								break;
/* ------------------------------ opt ------------------------- */
							case id_opt:
								a+=3;
								if(*(src+a)==EOL)
								{
									err_msg=4;
									next_line(src, &a);
									break;
								}
								if(inmacro)
								{
									err_msg=26;
									next_line(src, &a);
									break;
								}
								if((!rec_level) || (!qa))
								{
									while(*(src+a)==' ') { a++; }
									if((*(src+a+1)=='+') || (*(src+a+1)=='-'))
									{
										c=0;
										while((*(src+a)!=EOL) && (*(src+a)!=' ') && (!c))
										{
											switch(*(src+a))
											{
												case 'P':
													a++;
													if(*(src+a)=='+') print=1;
													else if(*(src+a)=='-') print=0;
													else err_msg=3;
													a++;
													break;
												case 'H':
													a++;
													if(*(src+a)=='+') header=0xffff;
													else if(*(src+a)=='-') header=0;
													else err_msg=3;
													a++;
													break;
												default:
													err_msg=3;
													c=1;
													break;
											}
										}
									}
									else
									{
										c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffff);
										if((c>0x7f) && (!err_msg)) err_msg=1;
										if(!err_msg)
										{
											if(c&0x02) print=1; else print=0;
											if((c&0x60)==0x60) header=0; else header=0xffff;
											if(c&0x1d) print_wrnmsg(orig, old_a, 3, line, report);
										}
									}
								}
								next_line(src, &a);
								break;
/* ------------------------------ blk ------------------------- */
/* ------------------------------ org ------------------------- */
							case id_blk:
							case id_org:
								a+=3;
								if(*(src+a)==EOL)
								{
									err_msg=4;
									next_line(src, &a);
									break;
								}
								if(inmacro)
								{
									err_msg=26;
									next_line(src, &a);
									break;
								}
								if(((blocks+1)%max_blocks)==0)
								{
									tmp_pnt=realloc(block_tab, (blocks+max_blocks)*sizeof(BLOCK));
									if(!tmp_pnt) err_msg=10;
									else { block_tab=tmp_pnt; }
								}
								d=0;
								if((block_tab[blocks].Start!=reg_pc) || ((block_tab[blocks].Header!=0xffff) && (block_tab[blocks].Header!=0xfeff) && (block_tab[blocks].Header!=0xfaff)))
								{
									d=0;
									if((block_tab[blocks].Header==0xfaff) || (block_tab[blocks].Header==0xffff))
										{ block_tab[blocks].End=reg_pc-1; }
									else
									{
										if(block_tab[blocks].Header==0xfeff)
										{
											b=block_tab[blocks].Mode;
											if((b==0x80) || (b==0x82))
											{
												d=0x1000;
												block_tab[blocks].End=reg_pc-0x1000;
												reg_pc+=block_tab[blocks].Start;
											}
											else block_tab[blocks].End=reg_pc-1;
											sparta_mem[blck_id-1]=sparta_mem[blck_id-2]+reg_pc-0x1000;
										}
										else block_tab[blocks].End=reg_pc;
									}
									c=(reg_pc-block_tab[blocks].Start)-d;
									if((block_tab[blocks].Header!=0xffff) && (block_tab[blocks].Header!=0xfaff) && (block_tab[blocks].Header!=0x0000)) delta=reg_pc-0x1000;
									if((cpu_mode&0x08)==0)
									{
										if((((block_tab[blocks].End&0xffff)+1)<(block_tab[blocks].Start&0xffff)) && (warnings) && (block_tab[blocks].Header!=0xfeff))
										{
											print_wrnmsg(orig, old_a, 2, block_tab[blocks].Line, 0);
											c=(0x10000-block_tab[blocks].Start)+block_tab[blocks].End+1;
										}
									}
									obj_len+=c;
								}
								else
								{
									block_tab[blocks].Need=0;
								}
								while(*(src+a)==' ') a++;
								b=0;
								if(*(src+a+1)==',')
								{
									b=0;
									switch(*(src+a))
									{
										case 'D':
											header=0xffff;
											addr_mode=0xffff;
											symb=0;
											a+=2;
											reg_pc=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											if(*(src+a)==',')
											{
												a++;
												b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											}
											else b=reg_pc;
											if((*(src+a)!=' ') && (*(src+a)!=EOL)) err_msg=3;
											ass=1;
											break;
										case 'E':
											header=0xfeff;
											addr_mode=0xfeff;
											symb=1;
											a+=2;
											if(*(src+a)=='E') { b=0x82; a++; }
											else if(*(src+a)=='M') { b=0x80; a++; }
											if((b) && (*(src+a)==',')) { a++; reg_pc=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff); }
											else { err_msg=2; }
											if(((*(src+a)!=' ') && (*(src+a)!=EOL)) || (!b)) err_msg=3;
											ass=0;
											break;
										case 'N':
											header=0x0000;
											addr_mode=0x0000;
											symb=0;
											a+=2;
											reg_pc=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											if((*(src+a)!=' ') && (*(src+a)!=EOL)) err_msg=3;
											ass=1;
											break;
										case 'R':
											header=0xfeff;
											addr_mode=0xfeff;
											symb=1;
											a+=2;
											reg_pc=0x1000+delta;
											if(*(src+a)=='E') { b=0x02; a++; }
											else if(*(src+a)=='M') { b=0x00; a++; }
											if((*(src+a)!=' ') && (*(src+a)!=EOL)) err_msg=3;
											ass=1;
											break;
										case 'S':
											header=0xfaff;
											addr_mode=0xfaff;
											symb=1;
											a+=2;
											reg_pc=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											if((*(src+a)!=' ') && (*(src+a)!=EOL)) err_msg=3;
											ass=1;
											break;
										case 'U':
											if(*(src+a+1)==',')
											{
												symb=0;
												ass=0;
												if(*(src+a+2)=='A')
												{
													if((*(src+a+3)!=' ') && (*(src+a+3)!=EOL)) err_msg=3;
													else a+=2;
													header=0xfdff;
													addr_mode=0xfdff;
													reg_pc=0x1000;
												}
												else
												{
													if(*(src+a+2)=='S')
													{
														if((*(src+a+3)!=' ') && (*(src+a+3)!=EOL)) err_msg=3;
														else a+=2;
														header=0xfbff;
														addr_mode=0xfbff;
														reg_pc=0x1000;
													}
													else
													{
														if(*(src+a+2)=='N')
														{
															a+=3;
															if(*(src+a)!=',') err_msg=15;
															if(*(src+a+1)==shift7)
															{
																c=0;
																a+=2;
																err_msg=9;
																while(c<9)
																{
																	if(*(src+a+c)==shift7) { err_msg=0; a+=c+1; c=19;}
																	c++;
																}
																if(c!=20) { err_msg=9; break; }
																if(*(src+a)==',') a++;
																else { err_msg=5; break; }
																addr_mode=get_value(src, orig, &a, reg_pc, line, &symb, 0xffff)-0x1000;
																if(cur_label>=0)
																{
																	if((cur_label>=0) && (!label_tab[cur_label].Block) && (!err_msg)) err_msg=24;
																	if(!label_tab[cur_label].Reloc) err_msg=11;
																	if(cur_label>=0) b=label_tab[cur_label].Block;
																	else b=0;
																}
																else err_msg=11;
																header=0xfcff;
																reg_pc=0x1000;
															}
															else err_msg=9;
														}
														else err_msg=3;
													}
												}
											}
											else err_msg=3;
											break;
									}
								}
								else
								{
/*									header=0xffff;
									addr_mode=0xffff;*/
									addr_mode=header;
									symb=0;
									reg_pc=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
									b=reg_pc;
									ass=1;
								}
								if(err_msg)
								{
									reg_pc=0x1000;
									next_line(src, &a);
									break;
								}
								blocks++;
								block_tab[blocks].Start=reg_pc;
								block_tab[blocks].Line=line;
								block_tab[blocks].Need=addr_mode;
								block_tab[blocks].Header=header;
								block_tab[blocks].Mode=b;
								if(header==0xfeff)
								{
									block_tab[blocks].Id=blck_id;
									blck_id++;
									if(blck_id>=max_sparta_blocks+2)
									{
										err_msg=10;
										next_line(src, &a);
										break;
									}
								}
								else block_tab[blocks].Id=0;
								if(((b==0x80) || (b==0x82)) && (header==0xfeff)) reg_pc=0x1000;
								next_line(src, &a);
								break;
							default:
								err_msg=12;
								next_line(src, &a);
								break;
						}
					}
				}
				if(done) break;
				for(b=0;b<macros;b++)
				{
					c=macro_tab[b].Name_Len;
					if((strncmp((const char *)(src+a), macro_tab[b].Name, c)==0) && ((*(src+a+c)==EOL) || (*(src+a+c)==' ')))
					{
						done=1;
						u_macros++;
						reg_pc+=macro_tab[b].Size;
						macro_tab[b].Need++;
						if(macro_tab[b].Params)
						{
							a+=c;
							while(*(src+a)==' ') a++;
							d=0;
							while((*(src+a)!=' ') && (*(src+a)!=EOL))
							{
								c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
								dta_ex=0;
								if(err_msg==7) err_msg=0;
								if(err_msg) { next_line(src, &a); a--; }
								if(inmacro)
								{
									macro_tab[macros].Diffs[param-1]+=macro_tab[b].Diffs[d];
								}
								else
								{
									if(c<0x100) reg_pc-=macro_tab[b].Diffs[d];
								}
								d++;
								if(*(src+a)==',') { a++; dta_ex=1; }
							}
							if((d<macro_tab[b].Params) || (dta_ex)) err_msg=2;
							else
								{ if(d>macro_tab[b].Params) print_wrnmsg(orig, old_a, 6, line, report); }
						}
						next_line(src, &a);
					}
					if(done) break;
				}
				if(!done)
				{
					err_msg=12;
					next_line(src, &a);
				}
				break;
			default:
				if((*(src+a)<0x1c) || (*(src+a)>=0x80) || (ifstack[iflevel]))
				{
					next_line(src, &a);
					break;
				}
/* etykiety i symbole */
				if(!ass)
				{
					err_msg=24;
					next_line(src, &a);
					break;
				}
				if (!(((*(src+a)>='A') && (*(src+a)<='Z')) || (*(src+a)=='_')))
					{ err_msg=3; next_line(src, &a); break; }
				b=get_label_name(src, &a, tmp_text);
				if (b) err_msg=b;
				while(*(src+a)==' ') a++;
				if (*(src+a)==EOL) err_msg=4;
				if ((strncmp((const char *)(src+a), symbols[0][id_smb], 3)==0) && (*(src+a+3)==' '))
				{
					a+=3;
					while(*(src+a)==' ') a++;
					if(*(src+a)==EOL)
					{
						err_msg=4;
						next_line(src, &a);
						break;
					}
					if(inmacro) err_msg=19;
					if(*(src+a)==shift7)
					{
						a++;
						c=strlen(tmp_text);
						symb_tab[smbls].Name=malloc((c+4)*sizeof(char));
						strcpy(symb_tab[smbls].Name, tmp_text);
						b=get_label_name(src, &a, tmp_text);
						if(b==6) b=0;
					}
					else b=9;
					if(b) err_msg=b;
					else
					{
						b=strlen(tmp_text);
						if((*(src+a)==shift7) && (b<9) && ((*(src+a+1)==EOL) || (*(src+a+1)==' ')))
						{
							while(b<8)
							{
								strcpy(tmp_text+b, " ");
								b++;
							}
							strcpy(symb_tab[smbls].Desc, tmp_text);
							symb_tab[smbls].Line=line;
						}
						else err_msg=9;
						if(((smbls+1)%max_symbols)==0)
						{
							tmp_pnt=realloc(symb_tab, (smbls+max_symbols)*sizeof(SYMBOL));
							if(!tmp_pnt) err_msg=16;
							else { symb_tab=tmp_pnt; }
						}
						smbls++;
					}
					next_line(src, &a);
					break;
				}
				if((strncmp((const char *)(src+a), symbols[0][id_mac], 3)==0) && ((*(src+a+3)==' ') || (*(src+a+3)==EOL)))
				{
					if(inmacro) { err_msg=3; next_line(src, &a); break; }
					if(((macros+1)%max_macros)==0)
					{
						tmp_pnt=realloc(macro_tab, (macros+max_macros)*sizeof(MACRO));
						if(!tmp_pnt)
						{
							printf(_("%s: Malloc crash! (macro_tab+)\n"), zooey_name);
							exit(3);
						}
						else { macro_tab=tmp_pnt; }
					}
					macro_tab[macros].Name=malloc((strlen(tmp_text)+4)*sizeof(unsigned char));
					macro_tab[macros].Diffs=malloc(max_params*sizeof(unsigned char));
					if((!macro_tab[macros].Name) || (!macro_tab[macros].Diffs))
					{
						printf(_("%s: Malloc crash! (macro_tab.Name)\n"), zooey_name);
						exit(3);
					}
					for(b=0;b<max_params;b++) macro_tab[macros].Diffs[b]=0;
					strcpy(macro_tab[macros].Name, tmp_text);
					macro_tab[macros].Name_Len=strlen(tmp_text);
					macro_tab[macros].Params=mac_params;
					macro_tab[macros].Need=0;
					macro_tab[macros].Size=reg_pc;
					macro_tab[macros].Src_Len=src_len;
					mac_params=0;
					reg_pc=0;
					inmacro++;
					next_line(src, &a);
					break;
				}
				if(((labels+1)%max_labels)==0)
				{
					tmp_pnt=realloc(label_tab, (labels+max_labels)*sizeof(LABEL));
					if(!tmp_pnt) err_msg=16;
					else { label_tab=tmp_pnt; }
				}
				c=strlen(tmp_text);
				label_tab[labels].Name=malloc((c+4)*sizeof(char));
				strcpy(label_tab[labels].Name, tmp_text);
				if((strncmp((const char *)(src+a), symbols[0][id_equ], 3)==0) && (*(src+a+3)==' '))
				{
					a+=3;
					if(inmacro) err_msg=19;
					while(*(src+a)==' ') a++;
					c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
					if(!err_msg)
					{
						if((block_tab[blocks].Header==0xfeff) && (symb==5)) { label_tab[labels].Reloc=1; symb=1; }
						else label_tab[labels].Reloc=0;
						label_tab[labels].Value=c;
						label_tab[labels].Need=0;
						label_tab[labels].Line=line;
						label_tab[labels].Total_Line=total_line;
						label_tab[labels].Block=block_tab[blocks].Id;
						cur_label=labels;
						labels++;
					}
					else {	if(err_msg==7) err_msg=0; }
				}
				else if (err_msg==0)
				{
					if(block_tab[blocks].Header==0xfeff) label_tab[labels].Reloc=1;
					else label_tab[labels].Reloc=0;
					label_tab[labels].Value=reg_pc;
					label_tab[labels].Need=0;
					label_tab[labels].Line=line;
					label_tab[labels].Block=block_tab[blocks].Id;
					cur_label=labels;
					labels++;
					goto rest_line;
				}
				next_line(src, &a);
				break;
/* koniec skanowania */
		}
	}
	if(!rec_level)
	{
		if((block_tab[blocks].Start!=reg_pc) || ((block_tab[blocks].Header!=0xffff) && (block_tab[blocks].Header!=0xfeff) && (block_tab[blocks].Header!=0xfaff)))
		{
			d=0;
			if((block_tab[blocks].Header==0xfaff) || (block_tab[blocks].Header==0xffff))
				{ block_tab[blocks].End=reg_pc-1; }
			else
			{
				if(block_tab[blocks].Header==0xfeff)
				{
					b=block_tab[blocks].Mode;
					if((b==0x80) || (b==0x82))
					{
						d=0x1000;
						block_tab[blocks].End=reg_pc-0x1000;
						reg_pc+=block_tab[blocks].Start;
					}
					else block_tab[blocks].End=reg_pc-1;
					sparta_mem[blck_id-1]=sparta_mem[blck_id-2]+reg_pc-0x1000;
				}
				else block_tab[blocks].End=reg_pc;
			}
			c=(reg_pc-block_tab[blocks].Start)-d;
			if((block_tab[blocks].Header!=0xffff) && (block_tab[blocks].Header!=0xfaff) && (block_tab[blocks].Header!=0x0000)) delta=reg_pc-0x1000;
			if(((block_tab[blocks].End+1)<block_tab[blocks].Start) && (warnings) && (block_tab[blocks].Header!=0xfeff))
			{
				print_wrnmsg(orig, old_a, 2, block_tab[blocks].Line, 0);
				c=(0x10000-block_tab[blocks].Start)+block_tab[blocks].End+1;
			}
			obj_len+=c;
		}
		else
		{
			block_tab[blocks].Need=0;
		}
		blocks++;
	}
	ret=1;
	if(iflevel) { printf(_("End of source%s\n"), _(errmsg[0][26])); errors++; }
	return errors;
}

unsigned int pass2(unsigned char *src, unsigned char *orig, unsigned int rec_level)
{
	unsigned int a=0, old_a=0, d, symb;
	unsigned int line=0, b, done, errors=0, addr_mode;
	int c=0;
	unsigned int value;
	unsigned char dta_ex=0, tmp_text[line_buffer], cpu_mode=1;

	if((block_tab[blocks].Need) && (!rec_level))
	{
		*(obj_buffer+obj_vect)=*(obj_buffer+obj_vect+1)=0xff;
		*(obj_buffer+obj_vect)=block_tab[blocks].Header>>8;
		*(obj_buffer+obj_vect+1)=block_tab[blocks].Header&0xff;
		*(obj_buffer+obj_vect+2)=block_tab[blocks].Start&0xff;
		*(obj_buffer+obj_vect+3)=(unsigned char)(block_tab[blocks].Start>>8);
		*(obj_buffer+obj_vect+4)=block_tab[blocks].End&0xff;
		*(obj_buffer+obj_vect+5)=(unsigned char)(block_tab[blocks].End>>8);
		obj_vect+=6;
		delta+=6;
		first_block=0;
	}
	symb=0;
	while(a<src_len)
	{
		total_line++;
		line++;
		done=0;
		if(err_msg)
		{
			if(rec_level) printf(_("\tIn file '%s':\n"), icl_tab[icls-1].File_Name);
			print_error(orig, old_a, err_msg, line-1, report);
			errors++;
			err_msg=0;
		}
		old_a=a;
		switch(*(src+a))
		{
			case '*':
			case '#':
			case ';':
				next_line(src, &a);
				break;
			default:
				if(*(src+a)==EOL) { a++; break; }
				if((*(src+a)!=' ') && (a<src_len))
				{
					if(ifstack[iflevel])
					{
						next_line(src, &a);
						break;
					}
					b=get_label_name(src, &a, tmp_text);
					if(b>0)
					{
						for(c=0;c<labels;c++)
							{
							if((label_tab[c].Line!=line) && (strcmp(tmp_text, label_tab[c].Name)==0)) { err_msg=6; break; } }
						for(c=0;c<smbls;c++)
							{
							if((symb_tab[c].Line!=line) && (strcmp(tmp_text, symb_tab[c].Name)==0)) { err_msg=6; break; } }
					}
					if(err_msg>0)
					{
						next_line(src, &a);
						break;
					}
					if((err_msg==0) && (b==0))
					{
						err_msg=0;
						label_tab[labels].Name=malloc((strlen(tmp_text)+4)*sizeof(char));
						strcpy(label_tab[labels].Name, tmp_text);
						while((*(src+a)==' ') && (a<src_len)) a++;
						if((strncmp((const char *)(src+a), symbols[0][id_equ], 3)==0) && (*(src+a+3)==' '))
						{
							a+=4;
							b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
							label_tab[labels].Reloc=0;
							label_tab[labels].Value=b;
							label_tab[labels].Need=0;
							label_tab[labels].Line=line;
							label_tab[labels].Total_Line=0xffffffff;
							label_tab[labels].Block=block_tab[blocks].Id;
							cur_label=labels;
							labels++;
							next_line(src, &a);
							break;
						}
						else
						{
							if((strncmp((const char *)(src+a), symbols[0][id_smb], 3)==0) && (*(src+a+3)==' '))
								{ next_line(src, &a); break; }
							if(strncmp((const char *)(src+a), symbols[0][id_mac], 3)!=0)
							{
								label_tab[labels].Reloc=0;
								label_tab[labels].Value=reg_pc;
								label_tab[labels].Need=0;
								label_tab[labels].Line=line;
								label_tab[labels].Total_Line=0xffffffff;
								label_tab[labels].Block=block_tab[blocks].Id;
								cur_label=labels;
								labels++;
							}
						}
					}
					else while((*(src+a)!=' ') && (a<src_len)) a++;
				}
				while((*(src+a)==' ') && (a<src_len)) a++;
				if (*(src+a)==EOL) { a++; break; }
				if(a>=src_len) break;
/* .komendy */
				if(!ifstack[iflevel])
				{
					for(b=0;b<=id_6502_last;b++)
					{
						if(strncmp((const char *)(src+a), mnemonics[0][b], 3)==0)
						{
							done=1;
							if(mch_code[b][11])
							{
								if (b!=id_brk) *(obj_buffer+obj_vect)=mch_code[b][11];
								else *(obj_buffer+obj_vect)=0x00;
								reg_pc++;
								obj_vect++;
								next_line(src, &a);
								break;
							}
							a+=3;
							addr_mode=get_addr_mode(src, a, reg_pc, total_line, &symb);
							if(addr_mode>=0x40) addr_mode=0;
							if(symb==2) symb=1;
							if (addr_mode==1) { while (*(src+a)==' ') a++; if (*(src+a)=='#') a++; }
							if ((addr_mode==8) || (addr_mode==9) || (addr_mode==10))
								{ { while (*(src+a)!='(') a++; } a++; }
							if((addr_mode==3) && (((mch_code[b][2]&0x1f)==0x10) || (b==id_bra))) addr_mode=2;
							*(obj_buffer+obj_vect)=mch_code[b][addr_mode];
							switch (addr_mode)
							{
								case 1:
								case 3:
								case 6:
								case 7:
								case 8:
								case 9:
									value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
									if (mch_code[b][addr_mode]==mch_code[b][2]) goto big_code; /* zp==abs */
									if (mch_code[b][addr_mode]==mch_code[b][5]) goto big_code; /* zp,y==abs,y */
									if (mch_code[b][addr_mode]==mch_code[b][4]) goto big_code; /* zp,x ==abs,x */
									if (value>0xff) { err_msg=1; reg_pc++; }
									*(obj_buffer+obj_vect+1)=(unsigned char)value&0xff;
									reg_pc+=2;
									obj_vect+=2;
									if((addr_mode==6) || (addr_mode==7)) a+=2; else if ((addr_mode==8) || (addr_mode==9)) a+=3;
									if ((*(src+a)!=' ') && (*(src+a)!=EOL))
										{ err_msg=3; }
									next_line(src, &a);
									break;
								case 2:
								case 4:
								case 5:
								case 10:
									d=a;
									if((block_tab[blocks].Header==0xfeff) || (block_tab[blocks].Header==0xfaff)) symb=1;
									value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
									if (value>0xffff) { err_msg=1; reg_pc++; }
									if ((addr_mode==2) && (((*(obj_buffer+obj_vect)&0x1f)==0x10) || (b==id_bra)))
									{
										reg_pc+=2;
										c=value-reg_pc;
										if (((value>reg_pc) && (c>0x7f)) || ((value<reg_pc) && (c<-128)))
											{ err_msg=14; }
										*(obj_buffer+obj_vect+1)=(unsigned char)c&0xff;
										obj_vect+=2;
									}
									else
									{
big_code:
										if((cur_label>=0) && (block_tab[blocks].Header==0xfeff) && (symb<10) && (label_tab[cur_label].Reloc) && (symb==5))
										{
											value-=0x1000;
											jump_tab[jumps].Adres=reg_pc+1-block_tab[blocks].Start;
											jump_tab[jumps].Block=(*(sparta_mem_map+value)<<8)+block_tab[blocks].Id;
											jumps++;
											symb=1;
										}
										if((cur_label>=0) && (block_tab[blocks].Header==0xfaff) && (symb<10) && (label_tab[cur_label].Reloc) && (symb==5))
										{
											value-=0x1000;
											jump_tab[jumps].Adres=(reg_pc+1);
											jump_tab[jumps].Block=(label_tab[cur_label].Block<<8)+0xff;
											jumps++;
											symb=1;
										}
										if(symb>=10)
										{
											if(block_tab[blocks].Header==0xfaff)
											{
												u_symb_tab[u_smbls].Block=0x0100;
												u_symb_tab[u_smbls].Adres=reg_pc+1;
											}
											else
											{
												u_symb_tab[u_smbls].Block=block_tab[blocks].Id;
												u_symb_tab[u_smbls].Adres=obj_vect+1-delta-block_tab[blocks].Mode;
											}
											u_symb_tab[u_smbls].Symbol=(symb-10);
											u_smbls++;
											symb=1;
										}
										*(obj_buffer+obj_vect+1)=(unsigned char)value&0xff;
										*(obj_buffer+obj_vect+2)=value>>8;
										reg_pc+=3;
										obj_vect+=3;
										if (addr_mode==10) a++; else if ((addr_mode==4) || (addr_mode==5) || (addr_mode==7)) a+=2;
									}
									if ((*(src+a)!=' ') && (*(src+a)!=EOL))
										{ err_msg=3; }
									next_line(src, &a);
									break;
								case 12:
									while (*(src+a)!='@') a++;
									a++;
									reg_pc++;
									obj_vect++;
									if ((*(src+a)!=' ') && (*(src+a)!=EOL)) err_msg=3;
									next_line(src, &a);
									break;
							}
							break;
						}
					}
					if(done) break;
				}
				if(*(src+a)=='.')
				{
					for(b=0;b<id_dot_cnst_last;b++)
					{
						if(strncmp((const char *)(src+a), dot_symbols[0][b], dot_symbol_len[b])==0)
						{
							done=1;
							switch(b)
							{
/* ------------------------------ .65c02 ------------------------- */
								case id_65c02:
									if(!ifstack[iflevel])
									{
										cpu_mode=cpu_mode|0x02;
										next_line(src, &a);
									}
									else done=0;
									break;
/* ------------------------------ .unpbl ------------------------- */
								case id_unpbl:
									if(!ifstack[iflevel])
									{
										cpu_mode=cpu_mode|0x02;
										next_line(src, &a);
									}
									else done=0;
									break;
/* ------------------------------ .atari ------------------------- */
/* ------------------------------ .unix -------------------------- */
/* ------------------------------ .dos --------------------------- */
								case id_atari:
								case id_unix:
								case id_dos:
									next_line(src, &a);
									break;
/* ------------------------------ .ifdef ----------------------- */
								case id_ifdef:
									if(iflevel==(max_depth-1)) err_msg=25;
									if((!err_msg) && (!ifstack[iflevel]) && (!ifignore))
									{
										a+=6;
										while(*(src+a)==' ') a++;
										b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
										iflevel++;
										if(err_msg!=7) ifstack[iflevel]=0;
										else ifstack[iflevel]=1;
										err_msg=0;
									}
									else ifignore++;
									next_line(src, &a);
									break;
/* ------------------------------ .if -------------------------- */
								case id_if:
									if(iflevel==(max_depth-1)) err_msg=25;
									if((!err_msg) && (!ifstack[iflevel]) && (!ifignore))
									{
										a+=3;
										while(*(src+a)==' ') a++;
										b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
										iflevel++;
										if(b) ifstack[iflevel]=0;
										else ifstack[iflevel]=1;
									}
									else ifignore++;
									next_line(src, &a);
									break;
/* ------------------------------ .else ------------------------ */
								case id_else:
									if(iflevel>0)
									{
										if(!ifignore)
										{
											if(ifstack[iflevel]==0) ifstack[iflevel]=13;
											else
											{
												if(ifstack[iflevel]==1) ifstack[iflevel]=0;
												else ifstack[iflevel]=3;
											}
										}
										next_line(src, &a);
									}
									else
									{
										if(!iflevel) err_msg=26;
										else err_msg=12;
										next_line(src, &a);
									}
									break;
/* ----------------------------- .elif ------------------------- */
								case id_elif:
									if(!iflevel) err_msg=26;
									if((!err_msg) && (!ifignore))
									{
										a+=5;
										while(*(src+a)==' ') a++;
										b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
										if((b) && (ifstack[iflevel]<10) && (ifstack[iflevel]>0)) ifstack[iflevel]=0;
										else
											{ if(ifstack[iflevel]==0) ifstack[iflevel]=12; }
									}
									next_line(src, &a);
									break;
/* ----------------------------- .fi --------------------------- */
								case id_fi:
									if(ifignore) ifignore--;
									else
									{
										if(!iflevel) err_msg=26;
										else iflevel--;
									}
									next_line(src, &a);
									break;
								default:
									err_msg=12;
									next_line(src, &a);
									break;
							}
						}
					}
					if(!done)
					{
						err_msg=12;
						next_line(src, &a);
					}
					break;
				}
				if(done) break;
				if(ifstack[iflevel])
				{
					next_line(src, &a);
					break;
				}
/* komendy QA */
				for(b=0;b<id_cnst_last;b++)
				{
					if((strncmp((const char *)(src+a), symbols[0][b], 3)==0) && (!ifstack[iflevel]))
					{
						done=1;
						switch(b)
						{
/* ------------------------------ bin ------------------------- */
							case id_bin:
								{
									FILE *tmp_file;
									unsigned int tmp_size=0;

									a+=3;
									while(*(src+a)==' ') a++;
									err_msg=get_file_name(orig, &a, tmp_text);
									tmp_file=fopen(tmp_text, "rb");
									if (tmp_file==NULL) { err_msg=18; }
									else
									{
										fseek(tmp_file, 0, SEEK_END);
										tmp_size=ftell(tmp_file);
										dta_ex=SEEK_SET;
									}
									if((*(src+a)==',') && (!err_msg))
									{
										if(*(src+a+1)=='-') { a+=2; dta_ex=SEEK_END; }
										else { a++; dta_ex=SEEK_SET; }
										c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
										if(dta_ex==SEEK_END) { b=c; c=c*-1; }
										else b=tmp_size-c;
										if((!err_msg) && (*(src+a)==','))
										{
											a++;
											b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											if((abs(b)+abs(c))>tmp_size) print_wrnmsg(orig, old_a, 4, line, report);
										}
									}
									else { b=tmp_size; }
									fseek(tmp_file, c, dta_ex);
									fread(obj_buffer+obj_vect, sizeof(unsigned char), b, tmp_file);
									obj_vect+=b;
									reg_pc+=b;
									fclose(tmp_file);
								}
								next_line(src, &a);
								break;
/* ------------------------------ cos ------------------------- */
							case id_cos:
								{
									double val, step, cnt;
									int d, seek;

									a+=3;
									c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
									while(*(src+a)!=EOL)
									{
										if(*(src+a)==',')
										{
											a++;
											b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											if(*(src+a)==',')
											{
												a++;
												seek=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											}
											else
												seek=0;
											step=360.0/(double)b;
											cnt=0.0;
											for(d=0;d<b;d++)
											{
												val=rint(cos(cnt*dev_pi)*(double)c);
												*(obj_buffer+obj_vect)=(int)val+seek;
												obj_vect++;
												cnt+=step;
											}
											break;
										}
										a++;
									}
									reg_pc+=b;
									next_line(src, &a);
								}
								break;
/* ------------------------------ dta ------------------------- */
							case id_dta:
								a+=4;
								if(*(src+a)==EOL)
								{
									err_msg=4;
									next_line(src, &a);
									break;
								}
								dta_ex=0;
								while(*(src+a)!=EOL)
								{
									err_msg=0;
									switch(*(src+a))
									{
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta A !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'A':
											dta_ex=1;
											a+=2;
											while(*(src+a)!=')')
											{
												value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												if(value>0xf0000000) value=value&0xffff;	// in case of -value
												if(value>0xffff) { err_msg=1; next_line(src, &a); break; }
												*(obj_buffer+obj_vect)=(unsigned char)(value&0xff);
												*(obj_buffer+obj_vect+1)=(unsigned char)(value>>8);
												obj_vect+=2;
												reg_pc+=2;
												while((*(src+a)==' ') && (a<src_len)) { a++; }
												if(*(src+a)==')') break;
												if(*(src+a)!=',') { err_msg=2; break; }
												a++;
											}
											if(err_msg)
											{
												while(*(src+a)!=EOL) { a++; }
												break;
											}
											a++;
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta V !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'V':
											dta_ex=1;
											a+=2;
											while(*(src+a)!=')')
											{
												value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												if(value>0xffff) { err_msg=1; next_line(src, &a); break; }
												if(((cur_label<=0) && (label_tab[cur_label].Reloc>0)) || (symb==5))
												{
													value-=0x1000;
												}
												*(obj_buffer+obj_vect)=(unsigned char)(value&0xff);
												*(obj_buffer+obj_vect+1)=(unsigned char)(value>>8);
												if((block_tab[blocks].Header==0xfeff) && (symb==5))
												{
													jump_tab[jumps].Adres=reg_pc-block_tab[blocks].Start;
													if(cur_label>=0)
														jump_tab[jumps].Block=(*(sparta_mem_map+value)<<8)+block_tab[blocks].Id;
													else
														jump_tab[jumps].Block=(block_tab[blocks].Id<<8)+block_tab[blocks].Id;
													jumps++;
													symb=1;
												}
												obj_vect+=2;
												reg_pc+=2;
												while((*(src+a)==' ') && (a<src_len)) { a++; }
												if(*(src+a)==')') break;
												if(*(src+a)!=',') { err_msg=2; break; }
												a++;
											}
											if(err_msg)
											{
												while(*(src+a)!=EOL) { a++; }
												break;
											}
											a++;
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta B !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'B':
											dta_ex=1;
											a+=2;
											while(*(src+a)!=')')
											{
												value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												if(value>0xf0000000) value=value&0xff;	// in case of -value
												*(obj_buffer+obj_vect)=(unsigned char)(value&0xff);
												obj_vect++;
												reg_pc++;
												if((value>0xff) && (err_msg==0)) err_msg=1;
												while((*(src+a)==' ') && (a<src_len)) { a++; }
												if(*(src+a)==')') break;
												if(*(src+a)!=',') { err_msg=2; break; }
												a++;
											}
											if(err_msg)
											{
												while(*(src+a)!=EOL) { a++; }
												break;
											}
											a++;
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta H !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'H':
											dta_ex=1;
											a+=2;
											while(*(src+a)!=')')
											{
												value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												if(value>0xf0000000) value=value&0xffff;	// in case of -value
												if(value>0xffff) { err_msg=1; next_line(src, &a); break; }
												*(obj_buffer+obj_vect)=(unsigned char)(value>>8);
												obj_vect++;
												reg_pc++;
												while((*(src+a)==' ') && (a<src_len)) { a++; }
												if(*(src+a)==')') break;
												if(*(src+a)!=',') { err_msg=2; break; }
												a++;
											}
											if(err_msg)
											{
												while(*(src+a)!=EOL) { a++; }
												break;
											}
											a++;
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta L !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'L':
											dta_ex=1;
											a+=2;
											while(*(src+a)!=')')
											{
												value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												if(value>0xf0000000) value=value&0xffff;	// in case of -value
												if(value>0xffff) { err_msg=1; next_line(src, &a); break; }
												*(obj_buffer+obj_vect)=(unsigned char)(value&0xff);
												obj_vect++;
												reg_pc++;
												while((*(src+a)==' ') && (a<src_len)) { a++; }
												if(*(src+a)==')') break;
												if(*(src+a)!=',') { err_msg=2; break; }
												a++;
											}
											if(err_msg)
											{
												while(*(src+a)!=EOL) { a++; }
												break;
											}
											a++;
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta C !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'C':
											dta_ex=1;
											a+=2;
											c=obj_vect;
											while(*(src+a)!=EOL)
											{
												if(*(src+a)==shift7)
												{
													a++;
													if(*(src+a)!=shift7) break;
												}
												*(obj_buffer+obj_vect)=*(orig+a);
												obj_vect++;
												reg_pc++;
												a++;
											}
											if(*(src+a)=='*')
											{
												for(value=c;value<obj_vect;value++)
													*(obj_buffer+value)=*(obj_buffer+value)^0x80;
												a++;
											}
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta D !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'D':
											{
												unsigned int d;

												dta_ex=1;
												a+=2;
												c=obj_vect;
												while(*(src+a)!=EOL)
												{
													if(*(src+a)==shift7)
													{
														a++;
														if(*(src+a)!=shift7) break;
													}
													d=*(orig+a);
													if(d<128) { if(d<32) d+=64; else if(d<96) d-=32; }
													else { if(d<160) d+=64; else if(d<224) d-=32; }
													*(obj_buffer+obj_vect)=d;
													obj_vect++;
													reg_pc++;
													a++;
												}
												if(*(src+a)=='*')
												{
													for(value=c;value<obj_vect;value++)
														*(obj_buffer+value)=*(obj_buffer+value)^0x80;
													a++;
												}
											}
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta E !!!!!!!!!!!!!!!!!!!!!!!!! */
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta T !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'E':
										case 'T':
											dta_ex=1;
											a+=2;
											while(*(src+a)!=')')
											{
												value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												if(value>0xf0000000) value=value&0xffffff;	// in case of -value
												if(value>0xffffff) { err_msg=1; next_line(src, &a); break; }
												*(obj_buffer+obj_vect)=(unsigned char)(value&0xff);
												*(obj_buffer+obj_vect+1)=(unsigned char)(value>>8);
												*(obj_buffer+obj_vect+2)=(unsigned char)(value>>16);
												obj_vect+=3;
												reg_pc+=3;
												while((*(src+a)==' ') && (a<src_len)) { a++; }
												if(*(src+a)==')') break;
												if(*(src+a)!=',') { err_msg=2; break; }
												a++;
											}
											if(err_msg)
											{
												while(*(src+a)!=EOL) { a++; }
												break;
											}
											a++;
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta F !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'F':
											dta_ex=1;
											a+=2;
											while(*(src+a)!=')')
											{
												value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												*(obj_buffer+obj_vect)=(unsigned char)(value&0xff);
												*(obj_buffer+obj_vect+1)=(unsigned char)(value>>8);
												*(obj_buffer+obj_vect+2)=(unsigned char)(value>>16);
												*(obj_buffer+obj_vect+3)=(unsigned char)(value>>24);
												obj_vect+=4;
												reg_pc+=4;
												while((*(src+a)==' ') && (a<src_len)) { a++; }
												if(*(src+a)==')') break;
												if(*(src+a)!=',') { err_msg=2; break; }
												a++;
											}
											if(err_msg)
											{
												while(*(src+a)!=EOL) { a++; }
												break;
											}
											a++;
											break;
/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! dta G !!!!!!!!!!!!!!!!!!!!!!!!! */
										case 'G':
											dta_ex=1;
											a+=2;
											while(*(src+a)!=')')
											{
												value=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
												*(obj_buffer+obj_vect)=(unsigned char)(value>>24);
												*(obj_buffer+obj_vect+1)=(unsigned char)(value>>16);
												*(obj_buffer+obj_vect+2)=(unsigned char)(value>>8);
												*(obj_buffer+obj_vect+3)=(unsigned char)(value&0xff);
												obj_vect+=4;
												reg_pc+=4;
												while((*(src+a)==' ') && (a<src_len)) { a++; }
												if(*(src+a)==')') break;
												if(*(src+a)!=',') { err_msg=2; break; }
												a++;
											}
											if(err_msg)
											{
												while(*(src+a)!=EOL) { a++; }
												break;
											}
											a++;
											break;
										case ',':
											if(dta_ex) { dta_ex=0; a++; }
											else
											{
												err_msg=3;
												next_line(src, &a);
											}
											break;
										case ' ':
											next_line(src, &a);
											a--;
											break;
										default:
											err_msg=3;
											while(*(src+a)!=EOL) { a++; }
											break;
									}
								}
								next_line(src, &a);
								break;
/* ------------------------------ end ------------------------- */
							case id_end:
								ret=1;
								return errors;
/* ------------------------------ equ ------------------------- */
/* ------------------------------ smb ------------------------- */
							case id_smb:
							case id_equ:
								next_line(src, &a);
								break;
/* ------------------------------ icl ------------------------- */
							case id_icl:
								{
									unsigned int bak_src_len;
									unsigned char *bak_src, *bak_orig, bak_EOL;

									if(icl_tab[icls].Length)
									{
										bak_src=src;
										bak_orig=orig;
										bak_EOL=EOL;
										bak_src_len=src_len;
										src=icl_tab[icls].Src_Buffer;
										orig=icl_tab[icls].Orig_Src;
										EOL=icl_tab[icls].EOL;
										src_len=icl_tab[icls].Length;
										icls++;
										ret=0;
										errors+=pass2(src, orig, rec_level+1);
										EOL=bak_EOL;
										orig=bak_orig;
										src=bak_src;
										src_len=bak_src_len;
									}
									else icls++;
									next_line(src, &a);
									if((rec_level) && (ret) && (qa)) return errors;
								}
								break;
/* ------------------------------ enm ------------------------- */
							case id_enm:
								inmacro--;
								u_macros--;
								a=bak[u_macros].A;
								line=bak[u_macros].Line;
								src=bak[u_macros].Src;
								orig=bak[u_macros].Orig;
								src_len=bak[u_macros].Src_Len;
								next_line(src, &a);
								break;
/* ------------------------------ mac ------------------------- */
							case id_mac:
								next_line(src, &a);
								c=macro_tab[macros].A;
								macro_tab[macros].A=a;
								macro_tab[macros].Orig_Src=orig;
								macro_tab[macros].Upper_Src=src;
								a=c;
								c=macro_tab[macros].Line;
								macro_tab[macros].Line=line+1;
								line=c;
								next_line(src, &a);
								macros++;
								break;
/* ------------------------------ mem ------------------------- */
							case id_mem:
								a+=3;
								while(*(src+a)==' ') { a++; }
								c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
								a++;
								if(err_msg==0) d=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
								else { c=0; d=0; }
								mem_tab[mem_cnt].Line=line;
								mem_tab[mem_cnt].Begin=c;
								mem_tab[mem_cnt].Length=d;
								mem_cnt++;
								next_line(src, &a);
								break;
/* ------------------------------ opt ------------------------- */
							case id_opt:
								next_line(src, &a);
								break;
/* ------------------------------ blk ------------------------- */
/* ------------------------------ org ------------------------- */
							case id_blk:
							case id_org:
								blocks++;
								if((block_tab[blocks].Need) || (block_tab[blocks].Header==0xfcff))
								{
									switch(block_tab[blocks].Header)
									{
										case 0xffff:
											if(first_block)
											{
												*(obj_buffer+obj_vect)=block_tab[blocks].Header>>8;
												*(obj_buffer+obj_vect+1)=block_tab[blocks].Header&0xff;
												first_block=0;
												obj_vect+=2;
												delta+=2;
											}
											c=block_tab[blocks].Mode-block_tab[blocks].Start;
											*(obj_buffer+obj_vect)=(block_tab[blocks].Start+c)&0xff;
											*(obj_buffer+obj_vect+1)=(unsigned char)((block_tab[blocks].Start+c)>>8);
											*(obj_buffer+obj_vect+2)=(block_tab[blocks].End+c)&0xff;
											*(obj_buffer+obj_vect+3)=(unsigned char)((block_tab[blocks].End+c)>>8);
											obj_vect+=4;
											delta+=4;
											seek=0;
											header=0xffff;
											break;
										case 0xfeff:
											*(obj_buffer+obj_vect)=block_tab[blocks].Header>>8;
											*(obj_buffer+obj_vect+1)=block_tab[blocks].Header&0xff;
											*(obj_buffer+obj_vect+2)=block_tab[blocks].Id;
											*(obj_buffer+obj_vect+3)=block_tab[blocks].Mode;
											if((block_tab[blocks].Mode==0x80) || (block_tab[blocks].Mode==0x82))
												b=block_tab[blocks].Start+block_tab[blocks].End;
											else b=block_tab[blocks].End-block_tab[blocks].Start+1;
											*(obj_buffer+obj_vect+4)=seek&0xff;
											*(obj_buffer+obj_vect+5)=seek>>8;
											*(obj_buffer+obj_vect+6)=b&0xff;
											*(obj_buffer+obj_vect+7)=b>>8;
											block_tab[blocks].Mode=seek;
											seek+=b;
											obj_vect+=8;
											delta+=8;
											header=0xfeff;
											break;
										case 0xfdff:
											if(jumps)
											{
												unsigned int e, f=0;

												e=obj_vect;												
												for(value=(blck_id-1);value>0;value--)
												{
													addr_mode=0;
													b=0;
													d=0;
													for(c=0;c<jumps;c++)
													{
														if((jump_tab[c].Block>>8)==value)
														{
															if(!addr_mode)
															{
																if(d) { *(obj_buffer+obj_vect)=0xfc; obj_vect++; }
																*(obj_buffer+obj_vect)=block_tab[blocks].Header>>8;
																*(obj_buffer+obj_vect+1)=block_tab[blocks].Header&0xff;
																*(obj_buffer+obj_vect+2)=value;
																*(obj_buffer+obj_vect+3)=*(obj_buffer+obj_vect+4)=0;
																obj_vect+=5;
																addr_mode=1;
															}
															if(b!=(jump_tab[c].Block&0xff))
															{
																if((jump_tab[c].Block&0xff)==0xff)
																{
																	*(obj_buffer+obj_vect)=0xfd;
																	*(obj_buffer+obj_vect+1)=jump_tab[c].Adres&0xff;
																	*(obj_buffer+obj_vect+2)=jump_tab[c].Adres>>8;
																	obj_vect+=3;
																	continue;
																}
																else
																{
																	*(obj_buffer+obj_vect)=0xfe;
																	obj_vect++;
																	b=jump_tab[c].Block&0xff;
																	*(obj_buffer+obj_vect)=b;
																	obj_vect++;
																	d=jump_tab[c].Adres;
																	f=jump_tab[c].Adres;
																}
															}
															else
															{
																d=jump_tab[c].Adres-f;
																f=jump_tab[c].Adres;
															}
															while(d>0xfb)
															{
																d-=0xfa;
																*(obj_buffer+obj_vect)=0xff;
																obj_vect++;
															}
															*(obj_buffer+obj_vect)=d;
															obj_vect++;
														}
													}
													if(addr_mode) { *(obj_buffer+obj_vect)=0xfc; obj_vect++; }
												}
												delta+=obj_vect-e;
											}
											header=0xfdff;
											break;
										case 0xfcff:
											*(obj_buffer+obj_vect)=block_tab[blocks].Header>>8;
											*(obj_buffer+obj_vect+1)=block_tab[blocks].Header&0xff;
											*(obj_buffer+obj_vect+2)=block_tab[blocks].Mode;
											*(obj_buffer+obj_vect+3)=block_tab[blocks].Need&0xff;
											*(obj_buffer+obj_vect+4)=block_tab[blocks].Need>>8;
											while(*(src+a)!=shift7) a++;
											a++;
											c=get_label_name(src, &a, tmp_text);
											if (c) err_msg=c;
											b=strlen(tmp_text);
											strcpy(obj_buffer+obj_vect+5, tmp_text);
											while(b<8)
											{
												*(obj_buffer+obj_vect+5+b)=' ';
												b++;
											}
											obj_vect+=13;
											delta+=13;
											header=0xfcff;
											break;
										case 0xfbff:
											if(u_smbls)
											{
												unsigned int e;

												e=obj_vect;
												for(value=0;value<smbls;value++)
												{
													if(symb_tab[value].Need>0)
													{
														*(obj_buffer+obj_vect)=block_tab[blocks].Header>>8;
														*(obj_buffer+obj_vect+1)=block_tab[blocks].Header&0xff;
														strncpy(obj_buffer+obj_vect+2, symb_tab[value].Desc, 8);
														*(obj_buffer+obj_vect+10)=*(obj_buffer+obj_vect+11)=0;
														obj_vect+=12;
														symb_tab[value].Need=0;
														d=0;
														addr_mode=0;
														for(c=0;c<u_smbls;c++)
														{
															if(u_symb_tab[c].Symbol==value)
															{
																if(u_symb_tab[c].Block==0x0100)
																{
																	*(obj_buffer+obj_vect)=0xfd;
																	*(obj_buffer+obj_vect+1)=u_symb_tab[c].Adres&0xff;
																	*(obj_buffer+obj_vect+2)=u_symb_tab[c].Adres>>8;
																	obj_vect+=3;
																	addr_mode=0;
																}
																else
																{
																	if(u_symb_tab[c].Block!=addr_mode)
																	{
																		addr_mode=u_symb_tab[c].Block;
																		*(obj_buffer+obj_vect)=0xfe;
																		*(obj_buffer+obj_vect+1)=addr_mode;
																		obj_vect+=2;
																		d=b=u_symb_tab[c].Adres;
																	}
																	else
																	{
																		d=u_symb_tab[c].Adres-b;
																		b=u_symb_tab[c].Adres;
																	}
																	while(d>0xfb)
																	{
																		d-=0xfa;
																		*(obj_buffer+obj_vect)=0xff;
																		obj_vect++;
																	}
																	*(obj_buffer+obj_vect)=d;
																	obj_vect++;
																}
															}
														}
														*(obj_buffer+obj_vect)=0xfc;
														obj_vect++;
													}
												}
												delta+=obj_vect-e;
											}
											u_smbls=0;
											header=0xfbff;
											break;
										case 0xfaff:
											*(obj_buffer+obj_vect)=block_tab[blocks].Header>>8;
											*(obj_buffer+obj_vect+1)=block_tab[blocks].Header&0xff;
											*(obj_buffer+obj_vect+2)=block_tab[blocks].Start&0xff;
											*(obj_buffer+obj_vect+3)=(unsigned char)(block_tab[blocks].Start>>8);
											*(obj_buffer+obj_vect+4)=block_tab[blocks].End&0xff;
											*(obj_buffer+obj_vect+5)=(unsigned char)(block_tab[blocks].End>>8);
											obj_vect+=6;
											delta+=6;
											header=0xfaff;
											break;
									}
									reg_pc=block_tab[blocks].Start;
								}
								next_line(src, &a);
								break;
/* ------------------------------ sin ------------------------- */
							case id_sin:
								{
									double val, step, cnt;
									int d, seek;

									a+=3;
									c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
									while(*(src+a)!=EOL)
									{
										if(*(src+a)==',')
										{
											a++;
											b=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											if(*(src+a)==',')
											{
												a++;
												seek=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
											}
											else
												seek=0;
											step=360.0/(double)b;
											cnt=0.0;
											for(d=0;d<b;d++)
											{
												val=rint(sin(cnt*dev_pi)*(double)c);
												*(obj_buffer+obj_vect)=(int)val+seek;
												obj_vect++;
												cnt+=step;
											}
											break;
										}
										a++;
									}
									reg_pc+=b;
									next_line(src, &a);
								}
								break;
							default:
								err_msg=12;
								next_line(src, &a);
								break;
						}
					}
					if(done) break;
				}
				for(b=0;b<macros;b++)
				{
					if((strncmp((const char *)(src+a), macro_tab[b].Name, macro_tab[b].Name_Len)==0) && ((*(src+a+macro_tab[b].Name_Len)==EOL) || (*(src+a+macro_tab[b].Name_Len)==' ')))
					{
						if(macro_tab[b].Params)
						{
							a+=macro_tab[b].Name_Len;
							while(*(src+a)==' ') a++;
							addr_mode=0;
							for(d=0;d<macro_tab[b].Params;d++)
							{
									c=get_value(src, orig, &a, reg_pc, line, &symb, 0xffffffff);
								mac_args[d]=c;
								if(*(src+a)==',') a++;
							}
						}
						bak[u_macros].A=a;
						bak[u_macros].Line=line;
						bak[u_macros].Src=src;
						bak[u_macros].Orig=orig;
						bak[u_macros].Src_Len=src_len;
						u_macros++;
						a=macro_tab[b].A;
						line=macro_tab[b].Line;
						src=macro_tab[b].Upper_Src;
						orig=macro_tab[b].Orig_Src;
						src_len=macro_tab[b].Src_Len;
						done=1;
						inmacro++;
						break;
					}
					if(done) break;
				}
				if(!done)
				{
					err_msg=12;
					next_line(src, &a);
				}
				else { break; }
/* koniec skanowania */
				break;
		}
	}
	ret=1;
	return errors;
}

int check_mem(void)
{
	unsigned int blck, c_blck;
	unsigned short int *mem_buf;
	unsigned short int a, b;
	unsigned char zp, st, hr, iv, ab;

	mem_buf=malloc(0x10000*sizeof(unsigned short int));
	if(mem_buf==NULL)
	{
		printf(_("%s: Malloc crash! (check_mem)\n"), zooey_name);
		return 3;
	}
	for(a=0;a<0x100;a++) *(mem_buf+a)=(unsigned short int)max_blocks+0x02;
	for(a=0x100;a<0x200;a++) *(mem_buf+a)=(unsigned short int)max_blocks+0x03;
	for(a=0x200;a<0xd000;a++) *(mem_buf+a)=(unsigned short int)max_blocks+0x01;
	for(a=0xd000;a<0xd800;a++) *(mem_buf+a)=(unsigned short int)max_blocks+0x04;
	for(a=0xd800;a<0xfffa;a++) *(mem_buf+a)=(unsigned short int)max_blocks+0x01;
	for(blck=0xfffa;blck<0x10000;blck++) *(mem_buf+blck)=(unsigned short int)max_blocks+0x05;
	for(a=0;a<mem_cnt;a++)
	{
		zp=st=hr=iv=ab=0;
		for(b=0;b<mem_tab[a].Length;b++)
		{
			if((*(mem_buf+mem_tab[a].Begin+b)>0) && (mem_tab[a].Status==0))
			{
				mem_tab[a].Status=1;
				switch(*(mem_buf+mem_tab[a].Begin+b))
				{
					case max_blocks+0x02:
						if(zp==0)
						{
							printf(_("Memory conflict between reserved area $%x - $%x (line %d) and zero page.\n"), mem_tab[b].Begin, mem_tab[b].Begin+mem_tab[b].Length, mem_tab[b].Line);
							zp=1;
						}
						break;
					case max_blocks+0x03:
						if(st==0)
						{
							printf(_("Memory conflict between reserved area $%x - $%x (line %d) and stack.\n"), mem_tab[b].Begin, mem_tab[b].Begin+mem_tab[b].Length, mem_tab[b].Line);
							st=1;
						}
						break;
					case max_blocks+0x04:
						if(hr==0)
						{
							printf(_("Memory conflict between reserved area $%x - $%x (line %d) and hardware registers.\n"), mem_tab[b].Begin, mem_tab[b].Begin+mem_tab[b].Length, mem_tab[b].Line);
							hr=1;
						}
						break;
					case max_blocks+0x05:
						if(iv==0)
						{
							printf(_("Memory conflict between reserved area $%x - $%x (line %d) and interrupt vectors.\n"), mem_tab[b].Begin, mem_tab[b].Begin+mem_tab[b].Length, mem_tab[b].Line);
							iv=1;
						}
						break;
				}
			}
			else *(mem_buf+mem_tab[a].Begin+b)=(unsigned short int)max_blocks+0x10+a;
		}
		mem_tab[a].Status=0;
	}
	for(blck=0;blck<=blocks;blck++)
	{
		if((block_tab[blck].Need) && ((block_tab[blck].Header==0xffff) || (block_tab[blck].Header==0xfaff)))
 		{
			c_blck=max_blocks+0x01;
			zp=st=hr=iv=ab=0;
			for(a=block_tab[blck].Start;a!=(block_tab[blck].End+1);a++)
			{
				c_blck=*(mem_buf+a);
				if(c_blck==max_blocks+0x01) *(mem_buf+a)=(unsigned short int)blck;
				if(c_blck!=max_blocks+0x01)
				{
					switch(c_blck)
					{
						case max_blocks+0x02:
							if(zp==0)
							{
								printf(_("Memory conflict between block $%x - $%x (line %d) and zero page.\n"), block_tab[blck].Start, block_tab[blck].End, block_tab[blck].Line);
								zp=1;
							}
							break;
						case max_blocks+0x03:
							if(st==0)
							{
								printf(_("Memory conflict between block $%x - $%x (line %d) and stack.\n"), block_tab[blck].Start, block_tab[blck].End, block_tab[blck].Line);
								st=1;
							}
							break;
						case max_blocks+0x04:
							if(hr==0)
							{
								printf(_("Memory conflict between block $%x - $%x (line %d) and hardware registers.\n"), block_tab[blck].Start, block_tab[blck].End, block_tab[blck].Line);
								hr=1;
							}
							break;
						case max_blocks+0x05:
							if(iv==0)
							{
								printf(_("Memory conflict between block $%x - $%x (line %d) and interrupt vectors.\n"), block_tab[blck].Start, block_tab[blck].End, block_tab[blck].Line);
								iv=1;
							}
							break;
						default:
							if(c_blck>=(max_blocks+0x10))
							{
								b=c_blck-max_blocks-0x10;
								if(mem_tab[b].Status==0)
									printf(_("Memory conflict between block $%x - $%x (line %d) and reserved area $%x - $%x (line %d).\n"), block_tab[blck].Start, block_tab[blck].End, block_tab[blck].Line, mem_tab[b].Begin, mem_tab[b].Begin+mem_tab[b].Length, mem_tab[b].Line);
								mem_tab[b].Status=1;
							}
							else if(ab==0)
							{
								printf(_("Memory conflict between block $%x - $%x (line %d) and block $%x - $%x (line %d).\n"), block_tab[blck].Start, block_tab[blck].End, block_tab[blck].Line, block_tab[c_blck].Start, block_tab[c_blck].End, block_tab[c_blck].Line);
								ab=1;
							}
							break;
					}
				}
			}
		}
	}
	free(mem_buf);
	return 0;
}

int main(int argcnt, char *argvec[])
{
	int a=0, wrt_lab, opt, b, c;
	char *output_fname=0, *label_fname=0, *src_fname, mem=0;
	unsigned char *orig_src, *src_buffer;

#ifdef GETTEXT
	setlocale(LC_ALL, "");
	bindtextdomain("zooey", LOCALES);
	textdomain("zooey");
#endif
	if(argcnt==1)
	{
		printf(_("Try: zooey -h.\n"));
		return 3;
	}
	mac_args=0;
	obj_buffer=0;
	u_symb_tab=jump_tab=0;
	symb_tab=0;
	sparta=0;
	wrt_lab=0;
	warnings=0;
	report=0;
	opterr=0;
	sparta_mem_map=0;
	labels=0;
	mem_tab=0;
	mem_cnt=0;
	qa=1;
	include_dirs=malloc(1*sizeof(char *));
	*include_dirs=NULL;
	while((opt=getopt(argcnt, argvec, "dhi:l:mo:rsvwz"))!=-1)
	{
		switch(opt)
		{
			case 'd':
				report=1;
				break;
			case 'h':
				printf(_("Usage: zooey [options] source_file\n6502 crossassembler.\nOptions:\n"));
				printf(_("-d\t\tdetailed information,\n-h\t\thelp,\n-i path\t\tinclude path,\n-l filename\tlabel's values report,\n-m\t\tcheck memory collisions,\n-o filename\toutput file name,\n-r\t\tif assembly fail, delete previously created output file,\n-s\t\tSpartaDOS paths style in 'icl',\n-v\t\tversion and quit,\n-w\t\tturn warnings on\n-z\t\tzooey behavior (turn off strange qa features).\n\nReport bugs to 'zooey-devel@lists.sourceforge.net'.\n"));
				printf("Copyright (C) 2000-2006,  Rafa� 'Bob_er' Ciepiela.\n");
				printf(_("This is free software; for details see attached 'copying' file or source files.\n"));
				return 4;
				break;
			case 'i':
				b=0;
				while(include_dirs[b]!=NULL) ++b;
				++b;
				include_dirs=realloc(include_dirs, b*sizeof(char *));
				c=strlen(optarg);
				include_dirs[b-1]=malloc(c+4);
				if(include_dirs[b-1]==NULL)
				{
					printf(_("%s: Malloc crash! (include_dirs)\n"), zooey_name);
					return 3;
				}
				strcpy(include_dirs[b-1], optarg);
				if(include_dirs[b-1][c-1]!='/')
				{
					include_dirs[b-1][c]='/';
					include_dirs[b-1][c+1]='\0';
				}
				include_dirs[b]=NULL;
				break;
			case 'l':
				label_fname=malloc(strlen(optarg)+4);
				if(label_fname==0)
				{
					printf(_("%s: Malloc crash! (label_fname)\n"), zooey_name);
					return 3;
				}
				strcpy(label_fname, optarg);
				wrt_lab=1;
				break;
			case 'm':
				mem=1;
				break;
			case 'o':
				output_fname=malloc(strlen(optarg)+4);
				if(output_fname==0)
				{
					printf(_("%s: Malloc crash! (output_fname)\n"), zooey_name);
					return 3;
				}
				strcpy(output_fname, optarg);
				break;
			case 'r':
				a=1;
				break;
			case 's':
				sparta=1;
				break;
			case 'v':
				printf("%s %s\n", zooey_name, zooey_version);
				return 4;
				break;
			case 'w':
				warnings=1;
				break;
			case 'z':
				qa=0;
				break;
			default:
				printf(_("Unknown option or bad argument. Try: zooey -h.\n"));
				exit(3);
		}
	}
	if(argvec[optind]!=NULL)
	{
		src_fname=malloc(strlen(argvec[optind])+4);
		if(src_fname==0)
		{
			printf(_("%s: Malloc crash! (src_fname)\n"), zooey_name);
			return 3;
		}
		strcpy(src_fname, argvec[optind]);
	}
	else
	{
		printf(_("%s: no file to assembly!\n"), zooey_name);
		return 3;
	}
	if(!output_fname)
	{
		printf(_("%s: no output filename!\n"), zooey_name);
		return 3;
	}
	if(a) unlink(output_fname);
	symb_tab=malloc((max_symbols+4)*sizeof(SYMBOL));
	if(symb_tab==0)
	{
		printf(_("%s: Malloc crash! (symb_tab)\n"), zooey_name);
		return 3;
	}
	errors=0;
	err_msg=0;
	obj_len=0;
	icls=0;
	blocks=0;
	header=print=0;
	reg_pc=0;
	if (report)
	{
		printf("%s %s\n", zooey_name, zooey_version);
	}
	a=load_src(src_fname, &src_buffer, &orig_src);
	if (a==1)
	{
		printf(_("Cannot read sorce file.\n"));
		return 2;
	}
	EOL=check_eol(src_buffer, src_len);
	if(report)
	{
		switch(EOL)
		{
			case 0x0a:
				printf(_("Setting UNIX($0a) EOL.\n"));
				break;
			case 0x9b:
				printf(_("Setting ATARI($9b) EOL.\n"));
				break;
			default:
				printf(_("This EOL ($%x) isn't implemented yet.\n"), EOL);
				return 2;
		}
	}
	ret=0;
	block_tab=malloc((max_blocks+4)*sizeof(BLOCK));
	if(block_tab==0)
	{
		printf(_("%s: Malloc crash! (block_tab)\n"), zooey_name);
		return 3;
	}
	label_tab=malloc((max_labels+4)*sizeof(LABEL));
	if(label_tab==0)
	{
		printf(_("%s: Malloc crash! (label_tab)\n"), zooey_name);
		return 3;
	}
	icl_tab=malloc((max_icls+4)*sizeof(ICL));
	if(icl_tab==0)
	{
		printf(_("%s: Malloc crash! (icl_tab)\n"), zooey_name);
		return 3;
	}
	macro_tab=malloc((max_macros+4)*sizeof(MACRO));
	if(macro_tab==0)
	{
		printf(_("%s: Malloc crash! (macro_tab)\n"), zooey_name);
		return 3;
	}
	macros=u_smbls=delta=smbls=jumps=u_macros=total_line=0;
	inmacro=mac_params=iflevel=ifignore=param=u_warnings=0;
	ifstack[iflevel]=0;
	sparta_mem[0]=0;
	if(pass1(src_buffer, orig_src, 0))
	{
		printf(_("Confused by earlier error(s), bailing out after first pass.\n"));
		return 2;
	}
	if(report) printf(_("Object file size without headers is %d bytes.\n"), obj_len);
	obj_buffer=malloc((obj_len+2+(blocks<<2))*sizeof(unsigned char)*4);
	if(obj_buffer==0)
	{
		printf(_("%s: Malloc crash! (obj_buffer)\n"), zooey_name);
		return 3;
	}
	if(mac_params)
	{
		mac_args=malloc((mac_params+2)+sizeof(unsigned int));
		if(mac_args==0)
		{
			printf(_("%s: Malloc crash! (mac_args)\n"), zooey_name);
			return 3;
		}
	}
	if(jumps>0)
	{
		jump_tab=malloc((jumps+2)*sizeof(JUMP)*2);
		if(jump_tab==0)
		{
			printf(_("%s: Malloc crash! (jump_tab)\n"), zooey_name);
			return 3;
		}
		memset(jump_tab, 0, (jumps+2)*sizeof(JUMP));
	}
	if(u_smbls>0)
	{
		u_symb_tab=malloc((u_smbls+2)*sizeof(JUMP)*2);
		if(u_symb_tab==0)
		{
			printf(_("%s: Malloc crash! (u_symb_tab)\n"), zooey_name);
			return 3;
		}
		memset(u_symb_tab, 0, (u_smbls+2)*sizeof(JUMP));
	}
	if(u_macros>0)
	{
		bak=malloc(u_macros*sizeof(BACKUP));
		if(bak==0)
		{
			printf(_("%s: Malloc crash! (bak)\n"), zooey_name);
			return 3;
		}
	}
	if(blck_id>1)
	{
		sparta_mem_map=malloc((sparta_mem[blck_id-1]+16)*sizeof(unsigned char));
		if(sparta_mem_map==0)
		{
			printf(_("%s: Malloc crash! (sparta_mem_map)\n"), zooey_name);
			return 3;
		}
		else
		{
			opt=0;
			for(a=1;a<blck_id;a++)
			{
				memset(sparta_mem_map+opt,a,sparta_mem[a]-opt);
				opt=sparta_mem[a];
			}
		}
	}
	if(mem_cnt>0)
	{
		mem_tab=malloc(mem_cnt*sizeof(MEM));
		if(mem_tab==0)
		{
			printf(_("%s: Malloc crash! (mem_tab)\n"), zooey_name);
			return 3;
		}
		mem_cnt=0;
	}
	for(a=0;a<labels;a++)
	{
		if(label_tab[a].Reloc==1)
		{
			print=0;
			for(opt=1;opt<blck_id;opt++)
			{
				if((label_tab[a].Value-0x1000)>=sparta_mem[opt]) continue;
				else { label_tab[a].Block=opt; print=1; break; }
			}
			if(!print) label_tab[a].Reloc=0;
		}
	}
	macros=u_smbls=delta=seek=jumps=blocks=icls=u_macros=total_line=0;
	header=print=0;
	first_block=1;
	reg_pc=0;
	obj_vect=0;
	ret=0;
	inmacro=0;
	iflevel=ifignore=0;
	ifstack[iflevel]=0;
	if(pass2(src_buffer, orig_src, 0))
	{
		printf(_("Confused by earlier error(s), bailing out after second pass.\n"));
		return 2;
	}
	if(report) printf(_("Object file size with headers is %d bytes.\n"), obj_vect);
	if(save_obj(output_fname, obj_buffer, obj_vect))
	{
		printf(_("Cannot create/write to output file.\n"));
		return 2;
	}
	if(warnings)
	{
		u_warnings++;
		for(a=0;a<labels;a++)
		{
			if(label_tab[a].Need==0) printf(_("Warning - Unused label '%s' (at line %d).\n"), label_tab[a].Name, label_tab[a].Line);
		}
		for(a=0;a<macros;a++)
		{
			if(macro_tab[a].Need==0) printf(_("Warning - Unused macro '%s' (at line %d).\n"), macro_tab[a].Name, macro_tab[a].Line-1);
		}
	}
	if(wrt_lab) save_lab(label_fname);
	if(block_tab) free(block_tab);
	if(mac_args) free(mac_args);
	if(label_tab) free(label_tab);
	if(icl_tab) free(icl_tab);
	if(label_fname) free(label_fname);
	if(output_fname) free(output_fname);
	if(src_fname) free(src_fname);
	if(jump_tab) free(jump_tab);
	if(symb_tab) free(symb_tab);
	if(u_symb_tab) free(u_symb_tab);
	if(bak) free(bak);
	if(sparta_mem_map) free(sparta_mem_map);
	if(mem) check_mem();
	if(mem_tab) free(mem_tab);
	if(include_dirs)
	{
		b=0;
		while(include_dirs[b]!=NULL) free(include_dirs[b++]);
		free(include_dirs);
	}
	if((u_warnings) && (warnings)) return 1;
	else return 0;
}
