#ifndef zooey10
#define zooey10

/* file: zooey.h
 * ZooEY 1.0
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* Parameters for zooey - don't change these values */

/* #define to_EOL while((*(src+a)!=EOL) && (a<src_len)){a++;} */
#define id_cnst_last 14
#define id_dot_cnst_last 10
#define id_dta 0
#define id_org 1
#define id_equ 2
#define id_opt 3
#define id_icl 4
#define id_bin 5
#define id_sin 6
#define id_cos 7
#define id_end 8
#define id_smb 9
#define id_blk 10
#define id_mac 11
#define id_enm 12
#define id_mem 13
#define id_65c02 0
#define id_unpbl 1
#define id_atari 2
#define id_unix 3
#define id_dos 4
#define id_ifdef 5
#define id_if 6
#define id_else 7
#define id_elif 8
#define id_fi 9
#define line_buffer 256
#define shift7 0x27
#define dev_pi 0.0174533
#define zooey_version VERSION
#define zooey_name "ZooEY"
#define max_labels 128
#define max_blocks 128
#define max_sparta_blocks 7
#define max_icls 32
#define max_symbols 32
#define max_depth 64
#define max_macros 32
#define max_params 24

#ifdef GETTEXT
#define _(String) gettext(String)
#define N_(String) (String)
#else
#define _(String) (String)
#define N_(String) (String)
#endif

/* global variables:
 * EOL - End Of Line value,
 * warnings - warnings on(>0)/off(==0),
 * report - if >0 - print detailed info,
 * src_len - source length (in bytes),
 * obj_len - object length (in bytes),
 * obj_vect - executable file size (in bytes),
 * err_msg - ID of error message,
 * errors - how much errors we have,
 * labels - how much labels we have,
 * blocks - how much blocks we have,
 * icls - how much icls we have,
 * ret - return flag (for ICL),
 * cur_label - latest label,
 * sparta - SpartaDOS paths style (if >0),
 * qa - qa specific behavior (turn off with '-z' option)
 */

static const char *symbols[4][14]={
	"DTA",
	"ORG",
	"EQU",
	"OPT",
	"ICL",
	"BIN",
	"SIN",
	"COS",
	"END",
	"SMB",
	"BLK",
	"MAC",
	"ENM",
	"MEM" };

static const char *dot_symbols[7][10]={
	".65C02",
	".UNPBL",
	".ATARI",
	".UNIX",
	".DOS",
	".IFDEF",
	".IF",
	".ELSE",
	".ELIF",
	".FI" };

static const char dot_symbol_len[]={6, 6, 6, 5, 4, 6, 3, 5, 5, 3};

static const char addr_modes[]={0, 1, 3, 2, 6, 7, 4, 5, 8, 9, 10, 11, 12};

static const char *errmsg[64][26]={
	"",
	N_(". ERROR - Too big number."),
	N_(". ERROR - Digit expected."),
	N_(". ERROR - Illegal symbol."),
	N_(". ERROR - Unexpected EOL."),
	N_(". ERROR - Label missing."),
	N_(". ERROR - Label decl twice."),
	N_(". ERROR - Undefined value."),
	N_(". ERROR - Unbal parenth."),
	N_(". ERROR - String error."),
	N_(". ERROR - Too much blocks."),
	N_(". ERROR - Improper type."),
	N_(". ERROR - Undefined symbol."),
	N_(". ERROR - Undefined or long."),
	N_(". ERROR - Branch too far."),
	N_(". ERROR - Illegal symbol or unexpected EOL."),
	N_(". ERROR - Too much labels or symbols."),
	N_(". ERROR - Illegal value."),
	N_(". ERROR - File not found."),
	N_(". ERROR - Declaration not allowed."),
	N_(". ERROR - Illegal option."),
	N_(". ERROR - EOL's symbols allowed only in first line."),
	N_(". ERROR - Too much InCLudes."),
	N_(". ERROR - Bad CPU."),
	N_(". ERROR - Improper block type."),
	N_(". ERROR - Too depth."),
	N_(". ERROR - Lost rest of structure.") };

static const char *wrnmsg[64][6]={
	"",
	N_(". Warning - .dos is not supported yet."),
	N_(". Warning - PC overflow in block."),
	N_(". Warning - OPT contains unsupported options."),
	N_(". Warning - Included block is bigger than a whole file."),
	N_(". Warning - JMP create an error (6502 CPU bug)."),
	N_(". Warning - Unnecessary argument") };

typedef struct {
	unsigned int Value;
	unsigned int Line;
	unsigned int Total_Line;
	unsigned int Need;
	unsigned char Block;
	unsigned char Reloc;
	char *Name;
} LABEL;

typedef struct {
	unsigned int Line;
	unsigned int Start;
	unsigned int End;
	unsigned short int Mode;
	unsigned short int Header;
	unsigned short int Need;
	unsigned char Id;
} BLOCK;

typedef struct {
	unsigned int Length;
	unsigned int Lines;
	char *File_Name;
	unsigned char *Src_Buffer;
	unsigned char *Orig_Src;
	unsigned char EOL;
} ICL;

typedef struct {
	unsigned int A;
	unsigned int Size;
	unsigned int Need;
	unsigned int Line;
	unsigned int Src_Len;
	unsigned char *Orig_Src;
	unsigned char *Upper_Src;
	char *Name;
	char *Diffs;
	char Params;
	char Name_Len;
} MACRO;

typedef struct {
	unsigned int Line;
	unsigned int Need;
	unsigned int Block;
	char *Name;
	char Desc[10];
} SYMBOL;

typedef struct {
	unsigned int Adres;
	unsigned int Block;
	unsigned int Symbol;
} JUMP;

typedef struct {
	unsigned int Line;
	unsigned int Begin;
	unsigned int Length;
	unsigned char Status;
} MEM;

typedef struct {
	unsigned int A;
	unsigned int Line;
	unsigned int Src_Len;
	unsigned char *Src;
	unsigned char *Orig;
} BACKUP;

unsigned int reg_pc, old_pc;
unsigned char blck_id, print, first_block;

BLOCK *block_tab;
LABEL *label_tab;
ICL *icl_tab;
SYMBOL *symb_tab;
JUMP *jump_tab, *u_symb_tab;
MACRO *macro_tab;
MEM *mem_tab;
BACKUP *bak;

void *tmp_pnt;
unsigned int sparta_mem[max_sparta_blocks];
unsigned int header, prv_header, src_len, err_msg, err_line, obj_len, errors, labels, blocks, obj_vect, delta, icls, jumps, smbls, u_smbls, seek, macros, u_macros, *mac_args, total_line, mem_cnt;
int cur_label;
unsigned char EOL, warnings, report, *obj_buffer, ret, sparta, ifstack[max_depth], iflevel, ifignore, inmacro, mac_params, param, u_warnings, *sparta_mem_map;
char **include_dirs, qa;

int load_src(char *, unsigned char **, unsigned char **);
int save_obj(char *, unsigned char *, unsigned int);
unsigned char check_eol(unsigned char *, unsigned int);
unsigned int get_number(unsigned char *, unsigned int *);
unsigned int get_label_value(unsigned char *, unsigned int *);
unsigned int get_file_name(unsigned char *, unsigned int *, unsigned char *);
unsigned int get_label_name(unsigned char *, unsigned int *, unsigned char *);
void next_line(unsigned char *, unsigned int *);
void print_error(unsigned char *, unsigned int, unsigned char, unsigned int, unsigned char);
void print_wrnmsg(unsigned char*, unsigned int, unsigned char, unsigned int, unsigned char);
unsigned int get_value(unsigned char *, unsigned char *, unsigned int *, unsigned short int, unsigned int, unsigned int *, unsigned int);
unsigned int calculate(unsigned int, unsigned int, unsigned int);
unsigned char get_addr_mode(unsigned char *, unsigned int, unsigned short int, unsigned int, unsigned int *);
unsigned int skip_operand(unsigned char *, unsigned int, unsigned char);
unsigned int pass1(unsigned char *, unsigned char *, unsigned int);
unsigned int pass2(unsigned char *, unsigned char *, unsigned int);
int check_mem(void);
int save_lab(char *);
int check_paths(char *);

#endif
